import { createContext, useContext, useEffect, useState } from 'react';
import { getMe, loginApi, registerApi } from '../services/auth.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));

  // Clear any mock flags on app initialization
  useEffect(() => {
    localStorage.removeItem('mock');
    localStorage.removeItem('mockRole');
  }, []);

  useEffect(() => {
    async function load() {
      if (!token) return;
      try {
        const me = await getMe(token);
        setUser(me.user);
      } catch {
        setToken(null);
        localStorage.removeItem('token');
      }
    }
    load();
  }, [token]);

  async function login(email, password) {
    // Clear any mock flags before authenticating
    localStorage.removeItem('mock');
    localStorage.removeItem('mockRole');
    
    const { token: t, user: u } = await loginApi(email, password);
    setToken(t);
    localStorage.setItem('token', t);
    setUser(u);
  }

  async function register(payload) {
    // Clear any mock flags before registering
    localStorage.removeItem('mock');
    localStorage.removeItem('mockRole');
    
    const { token: t, user: u } = await registerApi(payload);
    setToken(t);
    localStorage.setItem('token', t);
    setUser(u);
  }

  async function socialLogin(provider) {
    // Open popup to backend OAuth route and await token via postMessage
    const url = `/api/auth/${provider}`;
    const w = 600, h = 700;
    const y = window.top.outerHeight / 2 + window.top.screenY - ( h / 2);
    const x = window.top.outerWidth / 2 + window.top.screenX - ( w / 2);
    const popup = window.open(url, 'oauth', `width=${w},height=${h},left=${x},top=${y}`);
    if (!popup) throw new Error('Popup blocked');
    await new Promise((resolve, reject) => {
      const timer = setInterval(() => {
        if (popup.closed) {
          clearInterval(timer);
          window.removeEventListener('message', onMessage);
          reject(new Error('Popup closed'));
        }
      }, 500);
      function onMessage(e) {
        if (!e.data || !e.data.oauth) return;
        const { token: t, user: u } = e.data;
        clearInterval(timer);
        window.removeEventListener('message', onMessage);
        try { popup.close(); } catch {}
        setToken(t);
        localStorage.setItem('token', t);
        setUser(u);
        resolve();
      }
      window.addEventListener('message', onMessage);
    });
  }

  function logout() {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
    // Clear any demo/mock flags
    localStorage.removeItem('mock');
    localStorage.removeItem('mockRole');
  }

  return (
    <AuthContext.Provider value={{ user, token, login, register, logout, socialLogin }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}


