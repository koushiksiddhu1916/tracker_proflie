import { createContext, useContext, useEffect, useState } from 'react';

const DataRefreshContext = createContext(null);

export function DataRefreshProvider({ children }) {
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Listen for custom events from Accounts page
  useEffect(() => {
    const handleAccountSync = () => {
      console.log('Account synced - triggering data refresh');
      setRefreshTrigger(prev => prev + 1);
    };

    const handleAccountAdded = () => {
      console.log('Account added - triggering data refresh');
      setRefreshTrigger(prev => prev + 1);
    };

    const handleAccountDeleted = () => {
      console.log('Account deleted - triggering data refresh');
      setRefreshTrigger(prev => prev + 1);
    };

    window.addEventListener('account-synced', handleAccountSync);
    window.addEventListener('account-added', handleAccountAdded);
    window.addEventListener('account-deleted', handleAccountDeleted);

    return () => {
      window.removeEventListener('account-synced', handleAccountSync);
      window.removeEventListener('account-added', handleAccountAdded);
      window.removeEventListener('account-deleted', handleAccountDeleted);
    };
  }, []);

  const triggerRefresh = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <DataRefreshContext.Provider value={{ refreshTrigger, triggerRefresh }}>
      {children}
    </DataRefreshContext.Provider>
  );
}

export function useDataRefresh() {
  const context = useContext(DataRefreshContext);
  if (!context) {
    return { refreshTrigger: 0, triggerRefresh: () => {} };
  }
  return context;
}

