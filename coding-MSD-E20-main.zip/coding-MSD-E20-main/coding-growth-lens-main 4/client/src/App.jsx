import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import { ThemeProvider } from './context/ThemeContext.jsx';
import { DataRefreshProvider } from './context/DataRefreshContext.jsx';
import Login from './pages/Auth/Login.jsx';
import Register from './pages/Auth/Register.jsx';
import Landing from './pages/Landing.jsx';
import Forgot from './pages/Auth/Forgot.jsx';
import StudentDashboard from './pages/Student/Dashboard.jsx';
import Leaderboards from './pages/Shared/Leaderboards.jsx';
import NotFound from './pages/NotFound.jsx';
import Navbar from './components/layout/Navbar.jsx';
import Activity from './pages/Student/Activity.jsx';
import Settings from './pages/Settings.jsx';
import Accounts from './pages/Student/Accounts.jsx';
import Compiler from './pages/Student/Compiler.jsx';

function ProtectedRoute({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  return children;
}

function Home() {
  const { user } = useAuth();
  return user ? <StudentDashboard /> : <Landing />;
}

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <DataRefreshProvider>
          <Navbar />
          <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot" element={<Forgot />} />
          <Route
            path="/"
            element={<Home />}
          />
          <Route
            path="/leaderboards"
            element={
              <ProtectedRoute>
                <Leaderboards />
              </ProtectedRoute>
            }
          />
          <Route
            path="/activity"
            element={
              <ProtectedRoute>
                <Activity />
              </ProtectedRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <Settings />
              </ProtectedRoute>
            }
          />
          <Route
            path="/accounts"
            element={
              <ProtectedRoute>
                <Accounts />
              </ProtectedRoute>
            }
          />
          <Route
            path="/compiler"
            element={
              <ProtectedRoute>
                <Compiler />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<NotFound />} />
          </Routes>
        </DataRefreshProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}


