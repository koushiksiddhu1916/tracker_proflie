import { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useNavigate, Link } from 'react-router-dom';
import Button from '../../components/ui/Button.jsx';
import { Card, CardBody } from '../../components/ui/Card.jsx';
import { Field, Input } from '../../components/ui/Input.jsx';

export default function Register() {
  const { register, socialLogin } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', department: '', college: '', graduationYear: '' });
  const [error, setError] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [strength, setStrength] = useState(0);

  function update(field, value) {
    setForm((s) => ({ ...s, [field]: value }));
    if (field === 'password') {
      setStrength(scorePassword(value));
    }
  }

  function scorePassword(pw) {
    let score = 0;
    if (pw.length >= 8) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[a-z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;
    return score; // 0-5
  }

  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    try {
      await register({ ...form, graduationYear: form.graduationYear ? Number(form.graduationYear) : undefined });
      nav('/');
    } catch (err) {
      setError(err?.response?.data?.message || 'Registration failed');
    }
  }

  return (
    <div className="container-page py-16 min-h-screen flex items-center">
      <div className="max-w-2xl mx-auto w-full">
        <Card className="animate-fade-in">
          <CardBody>
            <div className="text-center mb-8">
              <h2 className="heading-hero mb-2">Create your account</h2>
              <p className="subtle">Start tracking your coding progress today</p>
            </div>
            <form onSubmit={onSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Field label="Name"><Input value={form.name} onChange={(e) => update('name', e.target.value)} placeholder="Your full name" required /></Field>
              <Field label="Email"><Input type="email" value={form.email} onChange={(e) => update('email', e.target.value)} placeholder="you@example.com" required /></Field>
              <Field label="Password" className="md:col-span-2">
                <div className="flex gap-2">
                  <Input type={showPassword ? 'text' : 'password'} value={form.password} onChange={(e) => update('password', e.target.value)} placeholder="Create a strong password" required />
                  <button type="button" className="btn btn-outline" onClick={() => setShowPassword((s) => !s)}>{showPassword ? 'Hide' : 'Show'}</button>
                </div>
                <div className="mt-2 h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-300" style={{ width: `${(strength/5)*100}%`, background: strength >= 4 ? '#16a34a' : strength >= 3 ? '#f59e0b' : '#ef4444' }} />
                </div>
                <div className="text-xs font-semibold mt-2" style={{ color: strength >= 4 ? '#16a34a' : strength >= 3 ? '#f59e0b' : '#ef4444' }}>
                  Password strength: {['Very weak','Weak','Okay','Good','Strong','Excellent'][strength]}
                </div>
              </Field>
              <Field label="Department"><Input value={form.department} onChange={(e) => update('department', e.target.value)} placeholder="e.g., Computer Science" /></Field>
              <Field label="College"><Input value={form.college} onChange={(e) => update('college', e.target.value)} placeholder="Your college name" /></Field>
              <Field label="Graduation Year"><Input type="number" value={form.graduationYear} onChange={(e) => update('graduationYear', e.target.value)} placeholder="e.g., 2025" /></Field>
              {error && <div className="col-span-full p-3 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800"><p className="text-sm text-red-600 dark:text-red-400">{error}</p></div>}
              <div className="col-span-full">
                <Button type="submit" className="w-full h-12 text-base shadow-lg">Create account</Button>
              </div>
              <div className="relative col-span-full my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-300 dark:border-slate-700"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white dark:bg-slate-900 subtle">Or sign up with</span>
                </div>
              </div>
              <div className="col-span-full grid grid-cols-2 gap-3">
                <Button type="button" variant="outline" className="h-11" onClick={() => socialLogin('google')}>🔵 Google</Button>
                <Button type="button" variant="outline" className="h-11" onClick={() => socialLogin('github')}>⚫ GitHub</Button>
              </div>
            </form>
            <p className="mt-4 text-sm subtle">Already have an account? <Link to="/login" className="text-brand-600">Login</Link></p>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}


