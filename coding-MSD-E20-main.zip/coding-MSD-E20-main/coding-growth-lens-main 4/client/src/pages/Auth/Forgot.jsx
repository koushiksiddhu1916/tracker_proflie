import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Card, CardBody } from '../../components/ui/Card.jsx';
import Button from '../../components/ui/Button.jsx';
import { Field, Input } from '../../components/ui/Input.jsx';
import { api } from '../../services/api.js';

export default function Forgot() {
  const nav = useNavigate();
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  async function onSubmit(e) {
    e.preventDefault();
    setError('');
    setMessage('');
    try {
      const { data } = await api().post('/auth/forgot', { email });
      setMessage(data.message || 'If that email exists, a reset link was sent.');
    } catch (e) {
      setError('Could not send reset email');
    }
  }

  return (
    <div className="container-page py-16 min-h-screen flex items-center">
      <div className="max-w-md mx-auto w-full">
        <Card className="animate-fade-in">
          <CardBody>
            <div className="text-center mb-8">
              <h2 className="heading-hero mb-2">Forgot password</h2>
              <p className="subtle">Enter your email to receive a reset link</p>
            </div>
            <form onSubmit={onSubmit} className="space-y-2">
              <Field label="Email">
                <Input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
              </Field>
              {message && <div className="p-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800"><p className="text-sm text-green-600 dark:text-green-400">{message}</p></div>}
              {error && <div className="p-3 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800"><p className="text-sm text-red-600 dark:text-red-400">{error}</p></div>}
              <Button type="submit" className="w-full h-12 text-base shadow-lg">Send reset link</Button>
            </form>
            <p className="mt-4 text-sm subtle">Remembered? <Link to="/login" className="text-brand-600">Back to login</Link></p>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}


