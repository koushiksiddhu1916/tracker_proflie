import { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useNavigate, Link } from 'react-router-dom';
import Button from '../../components/ui/Button.jsx';
import { Card, CardBody } from '../../components/ui/Card.jsx';
import { Field, Input } from '../../components/ui/Input.jsx';

export default function Login() {
  const { login, socialLogin } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [remember, setRemember] = useState(true);
  const [showPassword, setShowPassword] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setError(null);
    try {
      await login(email, password);
      if (!remember) {
        localStorage.removeItem('token');
      }
      nav('/');
    } catch (err) {
      setError(err?.response?.data?.message || 'Login failed');
    }
  }

  return (
    <div className="container-page py-16 min-h-screen flex items-center">
      <div className="max-w-md mx-auto w-full">
        <Card className="animate-fade-in">
          <CardBody>
            <div className="text-center mb-8">
              <h2 className="heading-hero mb-2">Welcome back</h2>
              <p className="subtle">Sign in to continue your coding journey</p>
            </div>
            <form onSubmit={onSubmit} className="space-y-4">
              <Field label="Email">
                <Input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="you@example.com" required />
              </Field>
              <Field label="Password">
                <div className="flex gap-2">
                  <Input value={password} onChange={(e) => setPassword(e.target.value)} type={showPassword ? 'text' : 'password'} placeholder="Enter your password" required />
                  <Button type="button" variant="outline" onClick={() => setShowPassword((s) => !s)}>{showPassword ? 'Hide' : 'Show'}</Button>
                </div>
              </Field>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
                Remember me
              </label>
              {error && <div className="p-3 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800"><p className="text-sm text-red-600 dark:text-red-400">{error}</p></div>}
              <Button type="submit" className="w-full h-12 text-base shadow-lg">Login</Button>
              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-300 dark:border-slate-700"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white dark:bg-slate-900 subtle">Or continue with</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Button type="button" variant="outline" className="h-11" onClick={() => socialLogin('google')}>🔵 Google</Button>
                <Button type="button" variant="outline" className="h-11" onClick={() => socialLogin('github')}>⚫ GitHub</Button>
              </div>
            </form>
            <p className="mt-4 text-sm subtle">New here? <Link to="/register" className="text-brand-600">Create an account</Link></p>
            <p className="mt-2 text-sm subtle">Forgot your password? <Link to="/forgot" className="text-brand-600">Reset it</Link></p>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}


