import { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { api } from '../../services/api.js';
import { Card, CardBody } from '../../components/ui/Card.jsx';

const LANGUAGES = {
  c: { name: 'C', value: 'c', extension: '.c', template: `#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}` },
  cpp: { name: 'C++', value: 'cpp', extension: '.cpp', template: `#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}` },
  java: { name: 'Java', value: 'java', extension: '.java', template: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}` },
  python: { name: 'Python', value: 'python', extension: '.py', template: `print("Hello, World!")` }
};

export default function Compiler() {
  const { token } = useAuth();
  const [selectedLanguage, setSelectedLanguage] = useState('cpp');
  const [code, setCode] = useState(LANGUAGES.cpp.template);
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [executionTime, setExecutionTime] = useState(null);

  const handleLanguageChange = (lang) => {
    setSelectedLanguage(lang);
    setCode(LANGUAGES[lang].template);
    setOutput('');
    setError('');
    setExecutionTime(null);
  };

  const handleRun = async () => {
    if (!code.trim()) {
      setError('Please write some code before running.');
      return;
    }

    setIsRunning(true);
    setOutput('');
    setError('');
    setExecutionTime(null);

    try {
      const startTime = Date.now();
      const { data } = await api(token).post('/student/compile', {
        language: selectedLanguage,
        code: code,
        stdin: input
      });

      const endTime = Date.now();
      setExecutionTime(((endTime - startTime) / 1000).toFixed(2));

      if (data.error) {
        setError(data.error);
        setOutput(data.stderr || '');
      } else {
        setOutput(data.stdout || '');
        if (data.stderr) {
          setError(data.stderr);
        }
      }
    } catch (err) {
      console.error('Compilation error:', err);
      setError(err.response?.data?.message || 'Failed to compile and run code. Please try again.');
    } finally {
      setIsRunning(false);
    }
  };

  const handleClear = () => {
    setCode(LANGUAGES[selectedLanguage].template);
    setInput('');
    setOutput('');
    setError('');
    setExecutionTime(null);
  };

  const handleReset = () => {
    setCode(LANGUAGES[selectedLanguage].template);
    setInput('');
    setOutput('');
    setError('');
    setExecutionTime(null);
  };

  return (
    <div className="container-page py-8 space-y-6 animate-fade-in">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="heading-hero mb-2">💻 Code Compiler</h2>
          <p className="text-sm subtle max-w-2xl">
            Write, compile, and run code in C, C++, Java, or Python. Test your code with custom input.
          </p>
        </div>
      </div>

      {/* Language Selector */}
      <Card className="shadow-lg">
        <CardBody>
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wide">Language:</span>
            {Object.entries(LANGUAGES).map(([key, lang]) => (
              <button
                key={key}
                onClick={() => handleLanguageChange(key)}
                className={`px-6 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 shadow-sm ${
                  selectedLanguage === key
                    ? 'bg-brand-600 text-white shadow-md hover:shadow-lg transform scale-105'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {lang.name}
              </button>
            ))}
          </div>
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code Editor */}
        <Card className="shadow-xl">
          <CardBody>
            <div className="flex items-center justify-between mb-4 pb-3 border-b-2 border-slate-200 dark:border-slate-700">
              <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">
                📝 Code Editor ({LANGUAGES[selectedLanguage].name})
              </h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleReset}
                  className="text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 transition-colors px-3 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  🔄 Reset
                </button>
                <button
                  onClick={handleRun}
                  disabled={isRunning}
                  className="btn btn-primary px-6 py-2 font-semibold shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isRunning ? '⏳ Running...' : '▶️ Run'}
                </button>
              </div>
            </div>
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full h-[500px] p-4 font-mono text-sm bg-slate-900 text-green-400 rounded-lg border-2 border-slate-300 dark:border-slate-700 focus:border-brand-500 focus:outline-none resize-none"
              placeholder="Write your code here..."
              spellCheck={false}
            />
            {executionTime && (
              <div className="mt-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                ⏱️ Execution time: {executionTime}s
              </div>
            )}
          </CardBody>
        </Card>

        {/* Input & Output */}
        <div className="space-y-6">
          {/* Input */}
          <Card className="shadow-xl">
            <CardBody>
              <div className="flex items-center justify-between mb-4 pb-3 border-b-2 border-slate-200 dark:border-slate-700">
                <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">📥 Input</h3>
                <button
                  onClick={() => setInput('')}
                  className="text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 transition-colors px-3 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Clear
                </button>
              </div>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="w-full h-[150px] p-4 font-mono text-sm bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-lg border-2 border-slate-300 dark:border-slate-700 focus:border-brand-500 focus:outline-none resize-none"
                placeholder="Enter input here (optional)..."
                spellCheck={false}
              />
            </CardBody>
          </Card>

          {/* Output */}
          <Card className="shadow-xl">
            <CardBody>
              <div className="flex items-center justify-between mb-4 pb-3 border-b-2 border-slate-200 dark:border-slate-700">
                <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">📤 Output</h3>
                <button
                  onClick={() => {
                    setOutput('');
                    setError('');
                  }}
                  className="text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 transition-colors px-3 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Clear
                </button>
              </div>
              {error && (
                <div className="mb-4 p-4 bg-red-50 dark:bg-red-950/30 border-2 border-red-200 dark:border-red-800 rounded-lg">
                  <div className="text-red-700 dark:text-red-400 font-mono text-sm whitespace-pre-wrap">
                    {error}
                  </div>
                </div>
              )}
              <textarea
                value={output}
                readOnly
                className={`w-full h-[300px] p-4 font-mono text-sm rounded-lg border-2 resize-none ${
                  error
                    ? 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800 text-red-700 dark:text-red-400'
                    : 'bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 border-slate-300 dark:border-slate-700'
                }`}
                placeholder="Output will appear here..."
                spellCheck={false}
              />
            </CardBody>
          </Card>
        </div>
      </div>

      {/* Tips */}
      <Card className="shadow-lg bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/30 dark:to-purple-950/30 border-2 border-blue-200 dark:border-blue-800">
        <CardBody>
          <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100 mb-4">💡 Tips</h3>
          <ul className="space-y-2 text-sm text-slate-700 dark:text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-brand-600 dark:text-brand-400 font-bold mt-0.5">•</span>
              <span><strong>C/C++:</strong> Make sure to include necessary headers (stdio.h for C, iostream for C++)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-600 dark:text-brand-400 font-bold mt-0.5">•</span>
              <span><strong>Java:</strong> Class name must be "Main" and must have a main method</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-600 dark:text-brand-400 font-bold mt-0.5">•</span>
              <span><strong>Python:</strong> Use Python 3 syntax. Input reading: <code className="bg-slate-200 dark:bg-slate-700 px-1 rounded">input()</code> for single line</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-600 dark:text-brand-400 font-bold mt-0.5">•</span>
              <span>Execution timeout is 10 seconds. Avoid infinite loops.</span>
            </li>
          </ul>
        </CardBody>
      </Card>
    </div>
  );
}

