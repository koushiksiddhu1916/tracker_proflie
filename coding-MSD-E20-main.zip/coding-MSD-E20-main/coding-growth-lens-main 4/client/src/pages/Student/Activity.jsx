import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useDataRefresh } from '../../context/DataRefreshContext.jsx';
import { api } from '../../services/api.js';
import { Card, CardBody } from '../../components/ui/Card.jsx';

export default function Activity() {
  const { token } = useAuth();
  const { refreshTrigger } = useDataRefresh();
  const [subs, setSubs] = useState([]);
  const [query, setQuery] = useState('');
  const [platform, setPlatform] = useState('all');
  const [difficulty, setDifficulty] = useState('all');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [sortBy, setSortBy] = useState('date_desc');
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const { data } = await api(token).get('/student/submissions?limit=200');
      setSubs(data.submissions || []);
    } catch (error) {
      console.error('Error loading submissions:', error);
      setSubs([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // Refresh every 30 seconds to show real-time data
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, refreshTrigger]); // Refresh when refreshTrigger changes

  // Show loading indicator when refreshing due to account sync
  useEffect(() => {
    if (refreshTrigger > 0) {
      console.log('Activity refreshing due to account sync...');
    }
  }, [refreshTrigger]);

  const filtered = useMemo(() => {
    return subs.filter((s) => {
      if (query && !s.title.toLowerCase().includes(query.toLowerCase())) return false;
      if (platform !== 'all' && s.platform !== platform) return false;
      if (difficulty !== 'all' && s.difficulty !== difficulty) return false;
      if (status !== 'all' && s.status !== status) return false;
      return true;
    });
  }, [subs, query, platform, difficulty, status]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    switch (sortBy) {
      case 'date_asc':
        arr.sort((a,b) => new Date(a.submittedAt) - new Date(b.submittedAt)); break;
      case 'title_asc':
        arr.sort((a,b) => a.title.localeCompare(b.title)); break;
      case 'title_desc':
        arr.sort((a,b) => b.title.localeCompare(a.title)); break;
      default:
        arr.sort((a,b) => new Date(b.submittedAt) - new Date(a.submittedAt));
    }
    return arr;
  }, [filtered, sortBy]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / perPage));
  const pageItems = sorted.slice((page - 1) * perPage, (page - 1) * perPage + perPage);

  function downloadCsv() {
    const rows = [['Platform','Title','Difficulty','Status','When'], ...filtered.map(s => [s.platform, s.title, s.difficulty, s.status, s.submittedAt ? new Date(s.submittedAt).toISOString() : ''])];
    const csv = rows.map(r => r.map(v => '"' + String(v).replaceAll('"','""') + '"').join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'activity.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="container-page py-8 animate-fade-in">
      {loading && refreshTrigger > 0 && (
        <div className="fixed top-20 right-4 bg-brand-600 text-white px-4 py-2 rounded-lg shadow-lg z-50 animate-fade-in flex items-center gap-2">
          <span className="animate-spin">🔄</span>
          <span className="font-semibold">Updating activity...</span>
        </div>
      )}
      <div className="mb-8">
        <h2 className="heading-hero mb-2">Recent Activity</h2>
        <p className="text-sm subtle max-w-2xl">
          Use filters to narrow results by platform, difficulty, and status. Sort, paginate, or export your filtered list as CSV.
        </p>
      </div>

      {/* Filters Section */}
      <Card className="mb-6 shadow-lg">
        <CardBody>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 uppercase tracking-wide">🔍 Search</label>
              <input 
                className="input w-full h-11 shadow-sm" 
                placeholder="Search by title..." 
                value={query} 
                onChange={(e) => setQuery(e.target.value)} 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 uppercase tracking-wide">🌐 Platform</label>
              <select 
                className="input w-full h-11 shadow-sm" 
                value={platform} 
                onChange={(e) => setPlatform(e.target.value)}
              >
                <option value="all">All platforms</option>
                <option value="leetcode">LeetCode</option>
                <option value="hackerrank">HackerRank</option>
                <option value="codechef">CodeChef</option>
                <option value="hackerearth">HackerEarth</option>
                <option value="codeforces">CodeForces</option>
                <option value="atcoder">AtCoder</option>
                <option value="geeksforgeeks">GeeksforGeeks</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 uppercase tracking-wide">⚡ Difficulty</label>
              <select 
                className="input w-full h-11 shadow-sm" 
                value={difficulty} 
                onChange={(e) => setDifficulty(e.target.value)}
              >
                <option value="all">All difficulties</option>
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 uppercase tracking-wide">✅ Status</label>
              <select 
                className="input w-full h-11 shadow-sm" 
                value={status} 
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="all">All statuses</option>
                <option value="Accepted">Accepted</option>
                <option value="Wrong Answer">Wrong Answer</option>
              </select>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3 pt-4 border-t-2 border-slate-200 dark:border-slate-800">
            <button 
              className="btn btn-primary h-11 px-6 font-semibold shadow-md hover:shadow-lg" 
              onClick={load}
              disabled={loading}
            >
              {loading ? '⏳ Loading...' : '🔄 Refresh'}
            </button>
            <select 
              className="input h-11 shadow-sm" 
              value={sortBy} 
              onChange={(e) => { setSortBy(e.target.value); setPage(1); }}
            >
              <option value="date_desc">📅 Newest first</option>
              <option value="date_asc">📅 Oldest first</option>
              <option value="title_asc">🔤 Title A-Z</option>
              <option value="title_desc">🔤 Title Z-A</option>
            </select>
            <button className="btn btn-outline h-11 px-6 font-semibold shadow-sm hover:shadow-md" onClick={downloadCsv}>
              📥 Export CSV
            </button>
            <div className="ml-auto text-sm font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-4 py-2 rounded-lg">
              {pageItems.length} of {filtered.length} results
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Table Section */}
      <Card className="overflow-hidden shadow-lg">
        <CardBody className="p-0">
          <div className="overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gradient-to-r from-slate-50 via-slate-100 to-slate-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 border-b-2 border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-5 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Platform</th>
                  <th className="p-5 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Title</th>
                  <th className="p-5 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Difficulty</th>
                  <th className="p-5 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Status</th>
                  <th className="p-5 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">When</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {pageItems.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-16 text-center">
                      <div className="text-slate-400 dark:text-slate-500">
                        <div className="text-6xl mb-4">📭</div>
                        <div className="text-xl font-bold mb-2">No activity found</div>
                        <div className="text-sm">Try adjusting your filters or refresh to load new data.</div>
                      </div>
                    </td>
                  </tr>
                ) : (
                  pageItems.map((s, idx) => (
                    <tr 
                      key={s._id} 
                      className={`transition-all duration-200 ${
                        idx % 2 === 0 
                          ? 'bg-white dark:bg-slate-900/50' 
                          : 'bg-slate-50/80 dark:bg-slate-900/30'
                      } hover:bg-gradient-to-r hover:from-brand-50/70 hover:to-purple-50/70 dark:hover:from-brand-900/30 dark:hover:to-purple-900/20 hover:shadow-sm`}
                    >
                      <td className="p-5">
                        <span className="badge badge-neutral capitalize font-semibold px-4 py-1.5 text-sm shadow-sm">
                          {s.platform}
                        </span>
                      </td>
                      <td className="p-5">
                        <div className="font-bold text-slate-900 dark:text-slate-100 text-base">{s.title}</div>
                      </td>
                      <td className="p-5">
                        <span className={`badge font-bold px-4 py-1.5 text-sm shadow-sm ${
                          s.difficulty === 'Easy' 
                            ? 'badge-success' 
                            : s.difficulty === 'Medium' 
                            ? 'badge-warning' 
                            : 'badge-danger'
                        }`}>
                          {s.difficulty}
                        </span>
                      </td>
                      <td className="p-5">
                        <span className={`badge font-bold px-4 py-1.5 text-sm shadow-sm ${
                          s.status === 'Accepted' 
                            ? 'badge-success' 
                            : 'badge-danger'
                        }`}>
                          {s.status === 'Accepted' ? '✓ Accepted' : '✗ ' + s.status}
                        </span>
                      </td>
                      <td className="p-5">
                        {s.submittedAt ? (
                          <div className="text-slate-600 dark:text-slate-400">
                            <div className="font-semibold text-sm">{new Date(s.submittedAt).toLocaleDateString()}</div>
                            <div className="text-xs mt-1 opacity-75">{new Date(s.submittedAt).toLocaleTimeString()}</div>
                          </div>
                        ) : (
                          <span className="text-slate-400 dark:text-slate-500">-</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Pagination */}
      {pageItems.length > 0 && (
        <div className="flex items-center justify-between mt-6">
          <div className="flex items-center gap-3">
            <span className="text-sm text-slate-600 dark:text-slate-400">Rows per page:</span>
            <select 
              className="input h-9 w-20" 
              value={perPage} 
              onChange={(e) => { setPerPage(Number(e.target.value)); setPage(1); }}
            >
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
          </div>
          <div className="flex items-center gap-3">
            <button 
              className="btn btn-outline h-9 px-4 disabled:opacity-50 disabled:cursor-not-allowed" 
              disabled={page === 1} 
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              ← Prev
            </button>
            <span className="text-sm font-medium text-slate-700 dark:text-slate-300 px-4">
              Page {page} of {totalPages}
            </span>
            <button 
              className="btn btn-outline h-9 px-4 disabled:opacity-50 disabled:cursor-not-allowed" 
              disabled={page === totalPages} 
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            >
              Next →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}


