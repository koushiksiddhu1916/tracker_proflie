import { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { useDataRefresh } from '../../context/DataRefreshContext.jsx';
import { api } from '../../services/api.js';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar, AreaChart, Area } from 'recharts';
import { Card, CardBody } from '../../components/ui/Card.jsx';

const COLORS = ['#4caf50', '#ff9800', '#f44336'];
const COLORS_DARK = ['#22c55e', '#f59e0b', '#ef4444'];

// Chart wrapper with error boundary
function ChartWrapper({ children, fallback = null, minHeight = 400 }) {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [children]);

  if (hasError) {
    return fallback || (
      <div className="flex items-center justify-center h-full min-h-[400px] text-slate-400">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <div className="text-sm">Chart could not be rendered</div>
        </div>
      </div>
    );
  }

  try {
    return (
      <div style={{ width: '100%', height: minHeight, minHeight: minHeight }}>
        <ResponsiveContainer>
          {children}
        </ResponsiveContainer>
      </div>
    );
  } catch (error) {
    console.error('Chart rendering error:', error);
    return fallback || (
      <div className="flex items-center justify-center h-full min-h-[400px] text-slate-400">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <div className="text-sm">Chart could not be rendered</div>
        </div>
      </div>
    );
  }
}

export default function StudentDashboard() {
  const { token } = useAuth();
  const { refreshTrigger } = useDataRefresh();
  const [stats, setStats] = useState({ 
    totalSolved: 0, 
    weeklyStreak: 0, 
    globalRank: 0, 
    byDifficulty: {}, 
    weeklyProgress: [],
    platformAccounts: [],
    platformRatings: {}
  });
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Check if dark mode is enabled
  const isDarkMode = document.documentElement.getAttribute('data-theme') === 'dark';

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const { data } = await api(token).get('/student/stats');
      setStats(data);
      const recentRes = await api(token).get('/student/submissions?limit=5');
      setRecent(recentRes.data.submissions || []);
    } catch (error) {
      console.error('Error loading dashboard:', error);
      setError('Failed to load dashboard data. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, refreshTrigger]);

  useEffect(() => {
    if (refreshTrigger > 0) {
      console.log('Dashboard refreshing due to account sync...');
    }
  }, [refreshTrigger]);

  // Memoized chart data
  const chartData = useMemo(() => [
    { name: 'Easy', value: stats.byDifficulty?.Easy || 0 },
    { name: 'Medium', value: stats.byDifficulty?.Medium || 0 },
    { name: 'Hard', value: stats.byDifficulty?.Hard || 0 }
  ].filter(item => item.value > 0), [stats.byDifficulty]);

  const platformChartData = useMemo(() => 
    stats.platformAccounts
      ? stats.platformAccounts
          .map(acc => ({
            name: acc.platform.charAt(0).toUpperCase() + acc.platform.slice(1),
            solved: (acc.metadata && acc.metadata.totalSolved) || 0,
            easy: (acc.metadata && acc.metadata.easySolved) || 0,
            medium: (acc.metadata && acc.metadata.mediumSolved) || 0,
            hard: (acc.metadata && acc.metadata.hardSolved) || 0
          }))
          .filter(acc => acc.solved > 0)
      : []
  , [stats.platformAccounts]);

  const ratingsChartData = useMemo(() =>
    stats.platformAccounts
      ? stats.platformAccounts
          .filter(acc => acc.metadata && acc.metadata.rating)
          .map(acc => ({
            name: acc.platform.charAt(0).toUpperCase() + acc.platform.slice(1),
            rating: acc.metadata.rating || 0,
            highestRating: acc.metadata.highestRating || acc.metadata.rating || 0
          }))
      : []
  , [stats.platformAccounts]);

  const difficultyTotal = (stats.byDifficulty?.Easy || 0) + (stats.byDifficulty?.Medium || 0) + (stats.byDifficulty?.Hard || 0);

  // Calculate insights
  const insights = useMemo(() => {
    const solved = stats.totalSolved || 0;
    const easy = stats.byDifficulty?.Easy || 0;
    const medium = stats.byDifficulty?.Medium || 0;
    const hard = stats.byDifficulty?.Hard || 0;
    const weeklyData = stats.weeklyProgress || [];
    const lastWeek = weeklyData[weeklyData.length - 1]?.solved || 0;
    const prevWeek = weeklyData[weeklyData.length - 2]?.solved || 0;
    const improvement = lastWeek > prevWeek ? ((lastWeek - prevWeek) / (prevWeek || 1)) * 100 : 0;
    
    return {
      totalSolved: solved,
      easyPercent: solved > 0 ? ((easy / solved) * 100).toFixed(1) : 0,
      mediumPercent: solved > 0 ? ((medium / solved) * 100).toFixed(1) : 0,
      hardPercent: solved > 0 ? ((hard / solved) * 100).toFixed(1) : 0,
      weeklyImprovement: improvement.toFixed(1),
      avgWeekly: weeklyData.length > 0 
        ? (weeklyData.reduce((sum, w) => sum + (w.solved || 0), 0) / weeklyData.length).toFixed(1)
        : 0
    };
  }, [stats]);

  // Calculate achievements
  const achievements = useMemo(() => {
    const achievements = [];
    if (stats.totalSolved >= 100) achievements.push({ icon: '🏆', title: 'Century Club', desc: 'Solved 100+ problems' });
    if (stats.totalSolved >= 50) achievements.push({ icon: '⭐', title: 'Half Century', desc: 'Solved 50+ problems' });
    if (stats.byDifficulty?.Hard >= 10) achievements.push({ icon: '💪', title: 'Hard Worker', desc: 'Solved 10+ hard problems' });
    if (stats.weeklyStreak >= 7) achievements.push({ icon: '🔥', title: 'Week Warrior', desc: '7+ day streak' });
    if (stats.platformAccounts?.length >= 3) achievements.push({ icon: '🌐', title: 'Multi-Platform', desc: 'Linked 3+ platforms' });
    if (stats.globalRank > 0 && stats.globalRank <= 100) achievements.push({ icon: '👑', title: 'Top 100', desc: 'Ranked in top 100' });
    return achievements;
  }, [stats]);

  const chartColors = isDarkMode ? COLORS_DARK : COLORS;
  const textColor = isDarkMode ? '#e2e8f0' : '#1e293b';
  const gridColor = isDarkMode ? '#334155' : '#e2e8f0';
  const tooltipBg = isDarkMode ? 'rgba(15, 23, 42, 0.95)' : 'rgba(255, 255, 255, 0.95)';
  const tooltipBorder = isDarkMode ? '#475569' : '#e2e8f0';

  return (
    <div className="container-page py-8 space-y-8 animate-fade-in">
      {loading && refreshTrigger > 0 && (
        <div className="fixed top-20 right-4 bg-brand-600 text-white px-4 py-2 rounded-lg shadow-lg z-50 animate-fade-in flex items-center gap-2">
          <span className="animate-spin">🔄</span>
          <span className="font-semibold">Updating data...</span>
        </div>
      )}
      
      {error && (
        <div className="bg-red-50 dark:bg-red-950/30 border-2 border-red-200 dark:border-red-800 rounded-xl p-4 text-red-700 dark:text-red-400">
          {error}
        </div>
      )}

      <div className="flex items-end justify-between">
        <div>
          <h2 className="heading-hero mb-2">My Dashboard</h2>
          <p className="text-sm subtle max-w-2xl">
            Track your overall progress: totals, difficulty breakdown, and weekly trend. Explore detailed logs in Activity or compete on Leaderboards.
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <Card className="group hover:scale-105 transition-transform duration-300 shadow-xl bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/30 dark:to-purple-950/30 border-2 border-blue-200 dark:border-blue-800">
          <CardBody>
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wide">Total Solved</div>
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-500 via-purple-500 to-pink-500 flex items-center justify-center text-white text-2xl shadow-lg transform group-hover:rotate-12 transition-transform">📊</div>
            </div>
            <div className="text-5xl font-black bg-gradient-to-r from-brand-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
              {stats.totalSolved}
            </div>
            {stats.platformAccounts && stats.platformAccounts.length > 0 && (
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-2">
                Across {stats.platformAccounts.length} platform{stats.platformAccounts.length > 1 ? 's' : ''}
                {difficultyTotal > 0 && difficultyTotal !== stats.totalSolved && (
                  <span className="text-amber-600 dark:text-amber-400 ml-1">
                    ({difficultyTotal} categorized)
                  </span>
                )}
              </div>
            )}
          </CardBody>
        </Card>
        <Card className="group hover:scale-105 transition-transform duration-300 shadow-xl bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 border-2 border-emerald-200 dark:border-emerald-800">
          <CardBody>
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wide">Weekly Streak</div>
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center text-white text-2xl shadow-lg transform group-hover:rotate-12 transition-transform">🔥</div>
            </div>
            <div className="text-5xl font-black bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 bg-clip-text text-transparent">{stats.weeklyStreak} <span className="text-2xl">days</span></div>
          </CardBody>
        </Card>
        <Card className="group hover:scale-105 transition-transform duration-300 shadow-xl bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/30 dark:to-orange-950/30 border-2 border-amber-200 dark:border-amber-800">
          <CardBody>
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wide">Global Rank</div>
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 via-orange-500 to-red-500 flex items-center justify-center text-white text-2xl shadow-lg transform group-hover:rotate-12 transition-transform">🏆</div>
            </div>
            <div className="text-5xl font-black bg-gradient-to-r from-amber-600 via-orange-600 to-red-600 bg-clip-text text-transparent">#{stats.globalRank || 'N/A'}</div>
          </CardBody>
        </Card>
      </div>

      {/* Insights Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="shadow-lg">
          <CardBody className="text-center py-4">
            <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{insights.easyPercent}%</div>
            <div className="text-xs subtle mt-1">Easy Problems</div>
          </CardBody>
        </Card>
        <Card className="shadow-lg">
          <CardBody className="text-center py-4">
            <div className="text-2xl font-bold text-amber-600 dark:text-amber-400">{insights.mediumPercent}%</div>
            <div className="text-xs subtle mt-1">Medium Problems</div>
          </CardBody>
        </Card>
        <Card className="shadow-lg">
          <CardBody className="text-center py-4">
            <div className="text-2xl font-bold text-red-600 dark:text-red-400">{insights.hardPercent}%</div>
            <div className="text-xs subtle mt-1">Hard Problems</div>
          </CardBody>
        </Card>
        <Card className="shadow-lg">
          <CardBody className="text-center py-4">
            <div className="text-2xl font-bold text-brand-600 dark:text-brand-400">{insights.avgWeekly}</div>
            <div className="text-xs subtle mt-1">Avg Weekly</div>
          </CardBody>
        </Card>
      </div>

      {/* Difficulty Breakdown Chart */}
      <Card className="shadow-xl">
        <CardBody>
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-2xl text-slate-900 dark:text-slate-100">Difficulty Breakdown</h3>
            <div className="text-sm subtle">Total: {difficultyTotal || stats.totalSolved}</div>
          </div>
          {chartData.length > 0 ? (
            <ChartWrapper minHeight={400}>
              <PieChart>
                <Pie 
                  data={chartData} 
                  dataKey="value" 
                  nameKey="name" 
                  cx="50%" 
                  cy="50%" 
                  outerRadius={140} 
                  innerRadius={60}
                  label={(entry) => `${entry.name}: ${entry.value}`}
                  labelLine={false}
                >
                  {chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={chartColors[index % chartColors.length]} 
                      stroke={isDarkMode ? '#1e293b' : '#fff'} 
                      strokeWidth={2} 
                    />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: tooltipBg, 
                    border: `2px solid ${tooltipBorder}`,
                    borderRadius: '12px',
                    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
                    color: textColor
                  }} 
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '20px', color: textColor }}
                  iconType="circle"
                />
              </PieChart>
            </ChartWrapper>
          ) : (
            <div className="flex items-center justify-center h-[400px] text-slate-400">
              <div className="text-center">
                <div className="text-4xl mb-3">📊</div>
                <div className="text-sm">No difficulty data available</div>
                <div className="text-xs mt-2">Start solving problems to see breakdown</div>
              </div>
            </div>
          )}
        </CardBody>
      </Card>

      {/* Weekly Progress Chart */}
      <Card className="shadow-xl">
        <CardBody>
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-2xl text-slate-900 dark:text-slate-100">Weekly Progress</h3>
            <div className="text-sm subtle">{stats.weeklyProgress?.length || 0} weeks tracked</div>
          </div>
          {stats.weeklyProgress && stats.weeklyProgress.length > 0 ? (
            <ChartWrapper minHeight={400}>
              <AreaChart data={stats.weeklyProgress} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSolved" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} opacity={0.5} />
                <XAxis 
                  dataKey="week" 
                  stroke={textColor} 
                  tick={{ fill: textColor, fontSize: 12 }}
                  label={{ value: 'Week', position: 'insideBottom', offset: -5, fill: textColor }}
                />
                <YAxis 
                  stroke={textColor} 
                  tick={{ fill: textColor, fontSize: 12 }}
                  label={{ value: 'Solved', angle: -90, position: 'insideLeft', fill: textColor }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: tooltipBg, 
                    border: `2px solid ${tooltipBorder}`,
                    borderRadius: '12px',
                    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
                    padding: '12px',
                    color: textColor
                  }} 
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '20px', color: textColor }}
                />
                <Area 
                  type="monotone" 
                  dataKey="solved" 
                  name="Solved per week" 
                  stroke="#4f46e5" 
                  strokeWidth={3}
                  fill="url(#colorSolved)"
                  animationDuration={1000}
                />
              </AreaChart>
            </ChartWrapper>
          ) : (
            <div className="flex items-center justify-center h-[400px] text-slate-400">
              <div className="text-center">
                <div className="text-4xl mb-3">📈</div>
                <div className="text-sm">No weekly progress data</div>
                <div className="text-xs mt-2">Your progress will appear here</div>
              </div>
            </div>
          )}
        </CardBody>
      </Card>

      {/* Platform Breakdown Chart */}
      {platformChartData.length > 0 && (
        <Card className="shadow-xl">
          <CardBody>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-2xl text-slate-900 dark:text-slate-100">Platform Breakdown by Difficulty</h3>
              <div className="text-sm subtle">Across {platformChartData.length} platform{platformChartData.length > 1 ? 's' : ''}</div>
            </div>
            <ChartWrapper minHeight={360}>
              <BarChart data={platformChartData} margin={{ top: 10, right: 24, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} opacity={0.5} />
                <XAxis dataKey="name" stroke={textColor} tick={{ fill: textColor }} />
                <YAxis stroke={textColor} tick={{ fill: textColor }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: tooltipBg, 
                    border: `1px solid ${tooltipBorder}`,
                    borderRadius: '8px',
                    color: textColor
                  }} 
                />
                <Legend wrapperStyle={{ color: textColor }} />
                <Bar dataKey="easy" stackId="a" fill="#4caf50" name="Easy" radius={[4, 4, 0, 0]} />
                <Bar dataKey="medium" stackId="a" fill="#ff9800" name="Medium" radius={[4, 4, 0, 0]} />
                <Bar dataKey="hard" stackId="a" fill="#f44336" name="Hard" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ChartWrapper>
          </CardBody>
        </Card>
      )}

      {/* Platform Ratings Chart */}
      {ratingsChartData.length > 0 && (
        <Card className="shadow-xl">
          <CardBody>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-2xl text-slate-900 dark:text-slate-100">Platform Ratings Comparison</h3>
              <div className="text-sm subtle">Current and highest ratings</div>
            </div>
            <ChartWrapper minHeight={360}>
              <BarChart data={ratingsChartData} margin={{ top: 10, right: 24, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} opacity={0.5} />
                <XAxis dataKey="name" stroke={textColor} tick={{ fill: textColor }} />
                <YAxis stroke={textColor} tick={{ fill: textColor }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: tooltipBg, 
                    border: `1px solid ${tooltipBorder}`,
                    borderRadius: '8px',
                    color: textColor
                  }} 
                />
                <Legend wrapperStyle={{ color: textColor }} />
                <Bar dataKey="rating" fill="#4f46e5" name="Current Rating" radius={[8, 8, 0, 0]} />
                <Bar dataKey="highestRating" fill="#8b5cf6" name="Highest Rating" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ChartWrapper>
          </CardBody>
        </Card>
      )}

      {/* Achievements Section */}
      {achievements.length > 0 && (
        <Card className="shadow-xl">
          <CardBody>
            <h3 className="font-bold text-2xl text-slate-900 dark:text-slate-100 mb-6">🏆 Achievements</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {achievements.map((achievement, idx) => (
                <div key={idx} className="text-center p-4 rounded-xl bg-gradient-to-br from-brand-50 to-purple-50 dark:from-brand-950/30 dark:to-purple-950/30 border-2 border-brand-200 dark:border-brand-800 hover:scale-105 transition-transform">
                  <div className="text-4xl mb-2">{achievement.icon}</div>
                  <div className="text-sm font-bold text-slate-900 dark:text-slate-100">{achievement.title}</div>
                  <div className="text-xs subtle mt-1">{achievement.desc}</div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      {/* Bottom Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="shadow-xl">
          <CardBody>
            <div className="flex items-center justify-between mb-4 pb-3 border-b-2 border-slate-200 dark:border-slate-700">
              <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">📝 Recent Activity</h3>
              <Link to="/activity" className="text-sm font-semibold text-brand-600 hover:text-brand-700 dark:text-brand-400 transition-colors">View all →</Link>
            </div>
            <div className="divide-y divide-slate-200 dark:divide-slate-800 space-y-2">
              {recent.map((s) => (
                <div key={s._id} className="py-4 flex items-center justify-between hover:bg-gradient-to-r hover:from-slate-50 hover:to-brand-50/50 dark:hover:from-slate-900/50 dark:hover:to-brand-900/20 rounded-xl px-3 transition-all duration-200 group">
                  <div className="flex-1">
                    <div className="text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">{s.title}</div>
                    <div className="text-xs subtle capitalize mt-2 flex items-center gap-2 flex-wrap">
                      <span className="badge badge-neutral font-semibold px-2 py-0.5">{s.platform}</span>
                      <span className={`badge font-semibold px-2 py-0.5 ${s.difficulty==='Easy' ? 'badge-success' : s.difficulty==='Medium' ? 'badge-warning' : 'badge-danger'}`}>{s.difficulty}</span>
                      <span className={`badge font-semibold px-2 py-0.5 ${s.status==='Accepted' ? 'badge-success' : 'badge-danger'}`}>{s.status}</span>
                    </div>
                  </div>
                  <div className="text-xs font-semibold subtle ml-4">{s.submittedAt ? new Date(s.submittedAt).toLocaleDateString() : ''}</div>
                </div>
              ))}
              {recent.length === 0 && (
                <div className="text-center py-12">
                  <div className="text-4xl mb-3">📭</div>
                  <div className="text-sm subtle">No recent activity</div>
                </div>
              )}
            </div>
          </CardBody>
        </Card>

        <Card className="shadow-xl">
          <CardBody>
            <div className="flex items-center justify-between mb-4 pb-3 border-b-2 border-slate-200 dark:border-slate-700">
              <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">🌐 Platform Accounts</h3>
              <Link to="/accounts" className="text-sm font-semibold text-brand-600 hover:text-brand-700 dark:text-brand-400 transition-colors">Manage →</Link>
            </div>
            <div className="space-y-3">
              {stats.platformAccounts && stats.platformAccounts.length > 0 ? (
                stats.platformAccounts.map((account) => {
                  const metadata = account.metadata || {};
                  const hasStats = metadata.totalSolved > 0 || metadata.rating;
                  return (
                    <div key={account.platform} className="p-4 rounded-xl border-2 border-slate-200 dark:border-slate-800 bg-gradient-to-br from-slate-50 to-white dark:from-slate-900/50 dark:to-slate-800/50 hover:shadow-md transition-all duration-200 group">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm font-bold capitalize text-slate-900 dark:text-slate-100 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                          {account.platform}
                        </span>
                        {account.lastSyncAt && (
                          <span className="text-xs font-semibold subtle bg-slate-200 dark:bg-slate-700 px-2 py-1 rounded-lg">
                            {new Date(account.lastSyncAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                      <div className="text-xs font-semibold subtle mb-2">@{account.handle}</div>
                      {hasStats ? (
                        <div className="space-y-2 mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
                          {metadata.totalSolved > 0 && (
                            <div className="flex items-center gap-2">
                              <span className="text-emerald-600 dark:text-emerald-400 text-lg">✓</span>
                              <span className="text-xs font-semibold">Solved: <span className="text-emerald-600 dark:text-emerald-400">{metadata.totalSolved}</span></span>
                            </div>
                          )}
                          {metadata.rating && (
                            <div className="flex items-center gap-2">
                              <span className="text-blue-600 dark:text-blue-400 text-lg">⭐</span>
                              <span className="text-xs font-semibold">Rating: <span className="text-blue-600 dark:text-blue-400">{metadata.rating}</span></span>
                              {metadata.globalRank && (
                                <span className="text-xs font-semibold subtle">• Rank: #{metadata.globalRank.toLocaleString()}</span>
                              )}
                            </div>
                          )}
                          {metadata.easySolved !== undefined && (
                            <div className="flex items-center gap-3 ml-4 text-xs font-semibold mt-2">
                              <span className="text-green-600 dark:text-green-400">E:{metadata.easySolved}</span>
                              {metadata.mediumSolved !== undefined && <span className="text-amber-600 dark:text-amber-400">M:{metadata.mediumSolved}</span>}
                              {metadata.hardSolved !== undefined && <span className="text-red-600 dark:text-red-400">H:{metadata.hardSolved}</span>}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-xs subtle mt-2 bg-slate-100 dark:bg-slate-800 px-3 py-2 rounded-lg">No stats yet. Sync to fetch data.</div>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8">
                  <div className="text-4xl mb-3">🔗</div>
                  <p className="text-sm subtle mb-3">No platform accounts linked</p>
                  <Link to="/accounts" className="text-brand-600 hover:text-brand-700 dark:text-brand-400 font-semibold transition-colors">Link your first account →</Link>
                </div>
              )}
            </div>
          </CardBody>
        </Card>

        <Card className="shadow-xl bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/30 dark:to-orange-950/30 border-2 border-amber-200 dark:border-amber-800">
          <CardBody>
            <div className="flex items-center gap-2 mb-6">
              <div className="text-2xl">🎯</div>
              <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">Quick Insights</h3>
            </div>
            <ul className="text-sm space-y-4">
              <li className="flex items-start gap-3 p-3 rounded-lg bg-white/50 dark:bg-slate-900/30">
                <span className="text-brand-500 text-xl font-bold mt-0.5">💡</span>
                <span className="text-slate-700 dark:text-slate-300 font-semibold flex-1">
                  {insights.weeklyImprovement > 0 ? `Up ${insights.weeklyImprovement}%` : 'Maintain consistency'} this week
                </span>
              </li>
              <li className="flex items-start gap-3 p-3 rounded-lg bg-white/50 dark:bg-slate-900/30">
                <span className="text-emerald-500 text-xl font-bold mt-0.5">📈</span>
                <span className="text-slate-700 dark:text-slate-300 font-semibold flex-1">
                  Average {insights.avgWeekly} problems per week
                </span>
              </li>
              <li className="flex items-start gap-3 p-3 rounded-lg bg-white/50 dark:bg-slate-900/30 border-2 border-amber-300 dark:border-amber-700">
                <span className="text-amber-500 text-xl font-bold mt-0.5">⚡</span>
                <span className="text-slate-700 dark:text-slate-300 font-semibold flex-1">
                  {stats.totalSolved >= 100 ? 'Century milestone reached!' : `Keep going! ${100 - stats.totalSolved} more to 100`}
                </span>
              </li>
            </ul>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
