import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { api } from '../../services/api.js';
import { Card, CardBody } from '../../components/ui/Card.jsx';
import Button from '../../components/ui/Button.jsx';
import { Field, Input, Select } from '../../components/ui/Input.jsx';

export default function Accounts() {
  const { token } = useAuth();
  const [accounts, setAccounts] = useState([]);
  const [form, setForm] = useState({ platform: 'leetcode', handle: '' });
  const [editingId, setEditingId] = useState(null);
  const [editHandle, setEditHandle] = useState('');
  const [syncing, setSyncing] = useState({});
  const [messages, setMessages] = useState({});

  async function load() {
    const { data } = await api(token).get('/student/accounts');
    setAccounts(data.accounts);
  }

  async function save(e) {
    e.preventDefault();
    try {
      const handleToSave = form.handle;
      const platformToSave = form.platform;
      const platformName = platformToSave.charAt(0).toUpperCase() + platformToSave.slice(1);
      
      const { data } = await api(token).post('/student/accounts', form);
      setForm({ platform: 'leetcode', handle: '' });
      await load();
      
      // Dispatch event to trigger real-time updates
      window.dispatchEvent(new CustomEvent('account-added', { 
        detail: { accountId: data.account?._id } 
      }));
      
      // Show success message
      setMessages(prev => ({ ...prev, success: `${platformName} account "${handleToSave}" added successfully! Syncing data...` }));
      setTimeout(() => setMessages(prev => ({ ...prev, success: null })), 5000);
      
      // Auto-sync after adding account
      if (data.account && data.account._id) {
        setTimeout(() => syncAccount(data.account._id), 1000);
      }
    } catch (error) {
      const errorMsg = error.response?.data?.message || 'Failed to add account';
      setMessages(prev => ({ ...prev, error: errorMsg }));
      setTimeout(() => setMessages(prev => ({ ...prev, error: null })), 5000);
    }
  }

  async function syncAccount(accountId) {
    setSyncing(prev => ({ ...prev, [accountId]: true }));
    setMessages(prev => ({ ...prev, [accountId]: null }));
    try {
      await api(token).post(`/student/accounts/${accountId}/sync`);
      await load();
      
      // Wait a moment for backend to process submissions and update stats
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Dispatch event to trigger real-time updates in other pages
      window.dispatchEvent(new CustomEvent('account-synced', { 
        detail: { accountId } 
      }));
      
      setMessages(prev => ({ ...prev, [accountId]: 'success', success: 'Account synced successfully! Data is updating in real-time across all pages.' }));
      setTimeout(() => setMessages(prev => ({ ...prev, [accountId]: null, success: null })), 5000);
    } catch (error) {
      const errorMsg = error.response?.data?.message || 'Failed to sync account';
      setMessages(prev => ({ ...prev, [accountId]: 'error', error: errorMsg }));
      setTimeout(() => setMessages(prev => ({ ...prev, [accountId]: null, error: null })), 5000);
    } finally {
      setSyncing(prev => ({ ...prev, [accountId]: false }));
    }
  }

  async function remove(id) {
    if (!confirm('Are you sure you want to delete this account?')) {
      return;
    }
    try {
      await api(token).delete(`/student/accounts/${id}`);
      await load();
      
      // Dispatch event to trigger real-time updates
      window.dispatchEvent(new CustomEvent('account-deleted', { 
        detail: { accountId: id } 
      }));
      
      setMessages(prev => ({ ...prev, success: 'Account deleted successfully! Data is updating in real-time.' }));
      setTimeout(() => setMessages(prev => ({ ...prev, success: null })), 3000);
    } catch (error) {
      const errorMsg = error.response?.data?.message || 'Failed to delete account';
      setMessages(prev => ({ ...prev, error: errorMsg }));
      setTimeout(() => setMessages(prev => ({ ...prev, error: null })), 5000);
    }
  }

  function startEdit(a) {
    setEditingId(a._id);
    setEditHandle(a.handle);
  }

  async function saveEdit(id) {
    try {
      await api(token).put(`/student/accounts/${id}`, { handle: editHandle });
      setEditingId(null);
      setEditHandle('');
      await load();
      setMessages(prev => ({ ...prev, success: 'Account updated successfully!' }));
      setTimeout(() => setMessages(prev => ({ ...prev, success: null })), 3000);
    } catch (error) {
      const errorMsg = error.response?.data?.message || 'Failed to update account';
      setMessages(prev => ({ ...prev, error: errorMsg }));
      setTimeout(() => setMessages(prev => ({ ...prev, error: null })), 5000);
    }
  }

  useEffect(() => { load(); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h3 className="heading-section mb-2">Linked Coding Platform Accounts</h3>
        <p className="text-sm subtle">Connect your coding platform accounts to sync your progress automatically</p>
      </div>
      {(messages.success || messages.error) && (
        <div className={`p-4 rounded-xl ${messages.success ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800' : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'}`}>
          <p className={`text-sm font-semibold ${messages.success ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
            {messages.success || messages.error}
          </p>
        </div>
      )}
      <Card>
        <CardBody>
          <form onSubmit={save} className="flex flex-col sm:flex-row gap-3">
            <Field label="Platform">
              <Select value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value })}>
                <option value="leetcode">LeetCode</option>
                <option value="hackerrank">HackerRank</option>
                <option value="codechef">CodeChef</option>
                <option value="hackerearth">HackerEarth</option>
                <option value="codeforces">CodeForces</option>
                <option value="atcoder">AtCoder</option>
                <option value="geeksforgeeks">GeeksforGeeks</option>
              </Select>
            </Field>
            <Field label="Username/Handle">
              <Input 
                placeholder={form.platform === 'leetcode' ? 'e.g., thanujkrishna22' : form.platform === 'codechef' ? 'e.g., thanuj15' : 'e.g., johndoe'} 
                value={form.handle} 
                onChange={(e) => setForm({ ...form, handle: e.target.value })} 
                required 
              />
            </Field>
            <div className="sm:self-end">
              <Button type="submit">Save</Button>
            </div>
          </form>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <div className="table-container">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-900/60">
                <tr className="text-left">
                  <th className="p-3">Platform</th>
                  <th className="p-3">Handle</th>
                  <th className="p-3">Stats</th>
                  <th className="p-3">Last Synced</th>
                  <th className="p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {accounts.map((a) => {
                  const metadata = a.metadata || {};
                  const isSyncing = syncing[a._id];
                  return (
                    <tr key={a._id} className="border-t border-slate-100 dark:border-slate-800 hover:bg-slate-50/60 dark:hover:bg-slate-900/40">
                      <td className="p-3">
                        <span className="badge badge-neutral capitalize">{a.platform}</span>
                      </td>
                      <td className="p-3 font-medium text-slate-900 dark:text-slate-100">
                        {editingId === a._id ? (
                          <div className="flex items-center gap-2">
                            <Input value={editHandle} onChange={(e) => setEditHandle(e.target.value)} className="w-32" />
                            <Button onClick={() => saveEdit(a._id)} className="h-8 px-2 text-xs">Save</Button>
                            <Button variant="outline" onClick={() => setEditingId(null)} className="h-8 px-2 text-xs">Cancel</Button>
                          </div>
                        ) : (
                          <span>{a.handle}</span>
                        )}
                      </td>
                      <td className="p-3">
                        <div className="text-xs space-y-1">
                          {metadata.totalSolved !== undefined && metadata.totalSolved > 0 && (
                            <div className="flex items-center gap-1">
                              <span className="text-emerald-600 dark:text-emerald-400">✓</span>
                              <span className="subtle">Solved: {metadata.totalSolved}</span>
                            </div>
                          )}
                          {metadata.easySolved !== undefined && (
                            <div className="flex items-center gap-1 ml-4">
                              <span className="text-green-500">Easy: {metadata.easySolved}</span>
                              {metadata.mediumSolved !== undefined && <span className="text-amber-500"> • Med: {metadata.mediumSolved}</span>}
                              {metadata.hardSolved !== undefined && <span className="text-red-500"> • Hard: {metadata.hardSolved}</span>}
                            </div>
                          )}
                          {metadata.rating !== undefined && metadata.rating !== null && (
                            <div className="flex items-center gap-1">
                              <span className="text-blue-600 dark:text-blue-400">⭐</span>
                              <span className="subtle">Rating: {metadata.rating}</span>
                              {metadata.highestRating && metadata.highestRating > metadata.rating && (
                                <span className="text-xs">(Best: {metadata.highestRating})</span>
                              )}
                            </div>
                          )}
                          {metadata.globalRank !== undefined && metadata.globalRank !== null && (
                            <div className="flex items-center gap-1">
                              <span className="text-amber-600 dark:text-amber-400">🏆</span>
                              <span className="subtle">Rank: #{metadata.globalRank.toLocaleString()}</span>
                            </div>
                          )}
                          {metadata.lastError && (
                            <div className="flex items-center gap-1 text-red-600 dark:text-red-400">
                              <span>⚠️</span>
                              <span className="text-xs">Sync error: {metadata.lastError}</span>
                            </div>
                          )}
                          {!metadata.totalSolved && !metadata.rating && !metadata.lastError && (
                            <span className="subtle">Click Sync to fetch data</span>
                          )}
                        </div>
                      </td>
                      <td className="p-3 text-xs subtle">
                        {a.lastSyncAt ? new Date(a.lastSyncAt).toLocaleString() : 'Never'}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          {messages[a._id] === 'success' && (
                            <span className="text-xs text-green-600 dark:text-green-400">✓ Synced</span>
                          )}
                          {messages[a._id] === 'error' && (
                            <span className="text-xs text-red-600 dark:text-red-400">✗ Failed</span>
                          )}
                          <Button 
                            variant="outline" 
                            onClick={() => syncAccount(a._id)}
                            disabled={isSyncing}
                            className="text-xs h-8 px-2"
                          >
                            {isSyncing ? '⏳ Syncing...' : '🔄 Sync'}
                          </Button>
                          {editingId !== a._id && (
                            <>
                              <Button variant="outline" onClick={() => startEdit(a)} className="text-xs h-8 px-2">Edit</Button>
                              <Button variant="outline" onClick={() => remove(a._id)} className="text-xs h-8 px-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20">Delete</Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {accounts.length === 0 && (
                  <tr>
                    <td colSpan="5" className="p-8 text-center subtle">
                      No accounts linked yet. Add your first coding platform account above!
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}


