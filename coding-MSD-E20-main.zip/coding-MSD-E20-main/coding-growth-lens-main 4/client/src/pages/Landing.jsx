import { Link } from 'react-router-dom';

export default function Landing() {
  return (
    <div className="space-y-24 animate-fade-in">
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-50 via-purple-50 to-blue-50 dark:from-brand-900/20 dark:via-purple-900/10 dark:to-blue-900/10 pointer-events-none" />
        <div className="container-page py-24 md:py-32 relative">
          <div className="max-w-5xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold bg-gradient-to-r from-brand-100 to-purple-100 text-brand-700 dark:from-brand-900/30 dark:to-purple-900/30 dark:text-brand-300 shadow-md animate-fade-in">
              ✨ New: Weekly progress insights and department leaderboards
            </div>
            <h1 className="mt-6 text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 dark:from-slate-100 dark:via-slate-200 dark:to-slate-100 bg-clip-text text-transparent leading-tight">
              Track Your Coding Journey, Amplify Your Growth
            </h1>
            <p className="mt-6 text-xl md:text-2xl text-slate-600 dark:text-slate-300 max-w-3xl mx-auto leading-relaxed">
              Connect LeetCode, HackerRank, CodeChef, and more. Visualize progress, compete on leaderboards, and accelerate your coding skills.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/login" className="btn btn-primary h-12 px-8 text-lg shadow-xl hover:shadow-2xl transform hover:scale-105">
                Get started
              </Link>
              <Link to="/register" className="btn btn-outline h-12 px-8 text-lg">
                Create free account
              </Link>
            </div>
            <div className="mt-14 grid grid-cols-1 sm:grid-cols-3 gap-6 text-left">
              <div className="card hover:scale-105 transition-transform duration-300">
                <div className="card-body">
                  <div className="text-4xl font-extrabold bg-gradient-to-r from-brand-600 to-purple-600 bg-clip-text text-transparent">150+</div>
                  <div className="text-sm subtle mt-2">Problems solved</div>
                </div>
              </div>
              <div className="card hover:scale-105 transition-transform duration-300">
                <div className="card-body">
                  <div className="text-4xl font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">6 weeks</div>
                  <div className="text-sm subtle mt-2">Active streak</div>
                </div>
              </div>
              <div className="card hover:scale-105 transition-transform duration-300">
                <div className="card-body">
                  <div className="text-4xl font-extrabold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">#124</div>
                  <div className="text-sm subtle mt-2">Global rank</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="container-page">
        <div className="text-center mb-12">
          <h2 className="heading-section mb-3">Why CodeTrack</h2>
          <p className="text-lg subtle max-w-2xl mx-auto">Everything you need to track and improve your coding skills, all in one place</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <FeatureCard title="Unified dashboard" desc="All platforms in one place with clean visuals and actionable insights." />
          <FeatureCard title="Competitive leaderboards" desc="Global, college, and department rankings to drive motivation." />
          <FeatureCard title="Smart activity filters" desc="Slice by platform, difficulty, and status to review your work quickly." />
          <FeatureCard title="Real-time sync" desc="Automatically sync your progress across all connected platforms." />
          <FeatureCard title="Progress analytics" desc="Track your growth with detailed charts and difficulty breakdowns." />
          <FeatureCard title="Privacy-first" desc="You control your data. Disconnect accounts anytime." />
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="container-page">
        <div className="text-center mb-12">
          <h2 className="heading-section mb-3">Loved by students and mentors</h2>
          <p className="text-lg subtle max-w-2xl mx-auto">See what our community has to say</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <Quote text="The unified dashboard helped me track my progress across all platforms. I finally hit a 6-week streak!" author="Alex K." />
          <Quote text="Our department leaderboard created healthy competition. My problem-solving rate doubled." author="Sarah M." />
        </div>
      </section>

      {/* FAQ */}
      <section className="container-page">
        <div className="text-center mb-12">
          <h2 className="heading-section mb-3">Frequently asked questions</h2>
          <p className="text-lg subtle">Everything you need to know</p>
        </div>
        <div className="max-w-3xl mx-auto space-y-4">
          <Faq q="Is it free to start?" a="Yes. You can create an account and connect platforms for free." />
          <Faq q="How does data sync work?" a="We securely fetch your public submission and activity data from connected platforms and aggregate it for insights." />
          <Faq q="Which platforms are supported?" a="Currently supporting LeetCode, HackerRank, CodeChef, HackerEarth, CodeForces, AtCoder, and GeeksforGeeks." />
        </div>
        <div className="mt-10 text-center">
          <Link to="/login" className="btn btn-primary h-12 px-8 text-lg shadow-xl">Start now</Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="container-page pb-12">
        <div className="text-sm subtle">© {new Date().getFullYear()} CodeTrack. All rights reserved.</div>
      </footer>
    </div>
  );
}

function FeatureCard({ title, desc }) {
  return (
    <div className="card group cursor-pointer">
      <div className="card-body">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-500 to-purple-500 mb-4 flex items-center justify-center text-white text-xl font-bold shadow-lg group-hover:scale-110 transition-transform duration-300">
          ✨
        </div>
        <h3 className="font-bold text-lg mb-2 text-slate-900 dark:text-slate-100">{title}</h3>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}

function Quote({ text, author }) {
  return (
    <div className="card">
      <div className="card-body">
        <div className="text-4xl text-brand-400 mb-3">"</div>
        <p className="text-base italic text-slate-700 dark:text-slate-300 leading-relaxed mb-4">"{text}"</p>
        <div className="text-sm font-semibold text-slate-600 dark:text-slate-400 border-t border-slate-200 dark:border-slate-800 pt-4">— {author}</div>
      </div>
    </div>
  );
}

function Faq({ q, a }) {
  return (
    <div className="card">
      <div className="card-body">
        <div className="font-bold text-lg mb-2 text-slate-900 dark:text-slate-100">{q}</div>
        <div className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{a}</div>
      </div>
    </div>
  );
}


