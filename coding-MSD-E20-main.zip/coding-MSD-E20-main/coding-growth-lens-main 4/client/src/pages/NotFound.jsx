import { Link } from 'react-router-dom';
import Button from '../components/ui/Button.jsx';
import { Card, CardBody } from '../components/ui/Card.jsx';

export default function NotFound() {
  return (
    <div className="container-page py-24 min-h-screen flex items-center justify-center">
      <div className="max-w-md mx-auto text-center animate-fade-in">
        <Card>
          <CardBody>
            <div className="text-8xl mb-4">🔍</div>
            <h1 className="heading-hero mb-4">404 - Page Not Found</h1>
            <p className="text-lg subtle mb-8">
              The page you're looking for doesn't exist or has been moved.
            </p>
            <Link to="/" className="btn btn-primary h-12 px-8">
              Go Home
            </Link>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}


