import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useDataRefresh } from '../../context/DataRefreshContext.jsx';
import { api } from '../../services/api.js';
import { Card, CardBody } from '../../components/ui/Card.jsx';

export default function Leaderboards() {
  const { token, user } = useAuth();
  const { refreshTrigger } = useDataRefresh();
  const [scope, setScope] = useState('global');
  const [results, setResults] = useState([]);
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [sortBy, setSortBy] = useState('rank'); // rank | solved | streak | name

  async function load() {
    try {
      const { data } = await api(token).get('/student/leaderboards', { params: { scope } });
      setResults(data.results || []);
    } catch (error) {
      console.error('Error loading leaderboards:', error);
      setResults([]);
    }
  }

  useEffect(() => {
    load();
    // Refresh every 30 seconds to show real-time data
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scope, refreshTrigger]); // Refresh when scope or refreshTrigger changes

  // Show loading indicator when refreshing due to account sync
  useEffect(() => {
    if (refreshTrigger > 0) {
      console.log('Leaderboards refreshing due to account sync...');
    }
  }, [refreshTrigger]);

  if (!user) return null;

  const sorted = (() => {
    const arr = [...results];
    switch (sortBy) {
      case 'solved': arr.sort((a,b) => b.solved - a.solved); break;
      case 'streak': arr.sort((a,b) => b.streak - a.streak); break;
      case 'name': arr.sort((a,b) => String(a.name).localeCompare(String(b.name))); break;
      default: arr.sort((a,b) => a.rank - b.rank);
    }
    return arr;
  })();
  const totalPages = Math.max(1, Math.ceil(sorted.length / perPage));
  const pageItems = sorted.slice((page - 1) * perPage, (page - 1) * perPage + perPage);

  function downloadCsv() {
    const rows = [['Rank','Name','Solved','Streak','Department'], ...results.map(r => [r.rank, r.name, r.solved, r.streak, r.department])];
    const csv = rows.map(r => r.map(v => '"' + String(v).replaceAll('"','""') + '"').join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'leaderboard.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="container-page py-8 space-y-6 animate-fade-in">
      <div className="mb-8">
        <h2 className="heading-hero mb-3">🏆 Leaderboards</h2>
        <p className="text-sm subtle max-w-2xl leading-relaxed">
          Compete with peers across different scopes. Track your ranking, solved problems, and streak. Your position is highlighted for easy identification.
        </p>
      </div>

      {/* Filters and Actions */}
      <div className="card">
        <CardBody>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex-1 min-w-[200px]">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Scope</label>
              <select value={scope} onChange={(e) => setScope(e.target.value)} className="input h-10 w-full">
                <option value="global">🌍 Global</option>
                <option value="college">🏫 College</option>
                <option value="department">📚 Department</option>
              </select>
            </div>
            <div className="flex-1 min-w-[200px]">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Sort By</label>
              <select value={sortBy} onChange={(e) => { setSortBy(e.target.value); setPage(1); }} className="input h-10 w-full">
                <option value="rank">📍 Rank</option>
                <option value="solved">✅ Solved</option>
                <option value="streak">🔥 Streak</option>
                <option value="name">🔤 Name</option>
              </select>
            </div>
            <div className="flex items-end">
              <button className="btn btn-primary h-10 px-6" onClick={downloadCsv}>
                📥 Export CSV
              </button>
            </div>
          </div>
        </CardBody>
      </div>

      {/* Leaderboard Table */}
      <Card className="overflow-hidden">
        <CardBody className="p-0">
          <div className="overflow-auto max-h-[65vh]">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-gradient-to-r from-slate-50 via-slate-100 to-slate-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 z-10 border-b-2 border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-4 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Rank</th>
                  <th className="p-4 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Name</th>
                  <th className="p-4 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Solved</th>
                  <th className="p-4 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Streak</th>
                  <th className="p-4 text-left font-bold text-slate-700 dark:text-slate-300 uppercase text-xs tracking-wider">Department</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {pageItems.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-12 text-center">
                      <div className="text-slate-400 dark:text-slate-500">
                        <div className="text-5xl mb-4">📊</div>
                        <div className="text-lg font-semibold mb-2">No leaderboard data</div>
                        <div className="text-sm">Try changing the scope or filters</div>
                      </div>
                    </td>
                  </tr>
                ) : (
                  pageItems.map((r) => {
                    const isYou = r.name?.toLowerCase().includes(user?.name?.toLowerCase?.() || '');
                    const medal = r.rank <= 3 ? (r.rank===1 ? '🥇' : r.rank===2 ? '🥈' : '🥉') : '';
                    const rankBg = r.rank === 1 ? 'bg-gradient-to-r from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20' :
                                   r.rank === 2 ? 'bg-gradient-to-r from-slate-50 to-gray-50 dark:from-slate-800/30 dark:to-gray-800/30' :
                                   r.rank === 3 ? 'bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20' : '';
                    return (
                      <tr 
                        key={r.rank} 
                        className={`transition-all duration-200 hover:bg-slate-50 dark:hover:bg-slate-900/60 ${
                          isYou ? 'bg-gradient-to-r from-yellow-50 via-yellow-50 to-transparent dark:from-yellow-900/30 dark:via-yellow-900/20 dark:to-transparent border-l-4 border-yellow-400' : ''
                        } ${rankBg} ${r.rank <= 3 ? 'font-semibold' : ''}`}
                      >
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            {medal && <span className="text-2xl">{medal}</span>}
                            <span className={`${r.rank <= 3 ? 'text-lg' : ''} ${isYou ? 'text-yellow-600 dark:text-yellow-400' : 'text-slate-700 dark:text-slate-300'}`}>
                              #{r.rank}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className={`font-medium ${isYou ? 'text-yellow-700 dark:text-yellow-300' : 'text-slate-900 dark:text-slate-100'}`}>
                            {r.name}
                            {isYou && <span className="ml-2 text-xs badge badge-warning">You</span>}
                          </span>
                        </td>
                        <td className="p-4">
                          <span className="badge badge-neutral font-semibold px-3 py-1.5 text-sm">
                            {r.solved}
                          </span>
                        </td>
                        <td className="p-4">
                          <span className="badge badge-success font-semibold px-3 py-1.5 text-sm">
                            🔥 {r.streak}d
                          </span>
                        </td>
                        <td className="p-4 text-slate-600 dark:text-slate-400 capitalize">{r.department || '-'}</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Pagination */}
      {pageItems.length > 0 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
          <div className="flex items-center gap-3">
            <span className="text-sm text-slate-600 dark:text-slate-400 font-medium">Rows per page:</span>
            <select className="input h-9 w-20" value={perPage} onChange={(e) => { setPerPage(Number(e.target.value)); setPage(1); }}>
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
            </select>
            <span className="text-sm subtle ml-2">
              Showing {((page - 1) * perPage) + 1}-{Math.min(page * perPage, sorted.length)} of {sorted.length}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button 
              className="btn btn-outline h-9 px-4 disabled:opacity-50 disabled:cursor-not-allowed transition-all" 
              disabled={page===1} 
              onClick={() => setPage((p)=>Math.max(1,p-1))}
            >
              ← Prev
            </button>
            <span className="text-sm font-semibold text-slate-700 dark:text-slate-300 px-4 min-w-[100px] text-center">
              Page {page} of {totalPages}
            </span>
            <button 
              className="btn btn-outline h-9 px-4 disabled:opacity-50 disabled:cursor-not-allowed transition-all" 
              disabled={page===totalPages} 
              onClick={() => setPage((p)=>Math.min(totalPages,p+1))}
            >
              Next →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}


