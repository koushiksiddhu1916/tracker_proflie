import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { Card, CardBody } from '../components/ui/Card.jsx';
import Button from '../components/ui/Button.jsx';
import { Field, Input } from '../components/ui/Input.jsx';

export default function Settings() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [avatar, setAvatar] = useState('');

  function onAvatarChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setAvatar(String(reader.result));
    reader.readAsDataURL(file);
  }

  function onSave(e) {
    e.preventDefault();
    // TODO: Call API to update profile
    alert('Profile updated successfully!');
  }

  return (
    <div className="container-page py-8 space-y-8 animate-fade-in">
      <div>
        <h2 className="heading-hero mb-2">Settings</h2>
        <p className="text-sm subtle max-w-2xl">
          Update your profile details. Changes will be saved to your account.
        </p>
      </div>

      <Card>
        <CardBody>
          <form onSubmit={onSave} className="grid grid-cols-1 sm:grid-cols-3 gap-6 items-start">
            <div className="sm:col-span-2">
              <Field label="Name">
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" required />
              </Field>
              <Field label="Email">
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
              </Field>
              <Button type="submit">Save changes</Button>
            </div>
            <div>
              <div className="text-sm subtle mb-2">Avatar</div>
              {avatar ? (
                <img src={avatar} alt="avatar" className="w-32 h-32 rounded-full object-cover border-4 border-slate-200 dark:border-slate-800 shadow-lg" />
              ) : (
                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900 flex items-center justify-center text-slate-400 border-4 border-slate-200 dark:border-slate-800 shadow-lg">
                  <span className="text-4xl">👤</span>
                </div>
              )}
              <input type="file" accept="image/*" className="mt-4 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100 dark:file:bg-brand-900/30 dark:file:text-brand-300 cursor-pointer" onChange={onAvatarChange} />
            </div>
          </form>
        </CardBody>
      </Card>
    </div>
  );
}


