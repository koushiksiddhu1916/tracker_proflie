import { Link } from 'react-router-dom';
import { Card, CardBody } from '../../components/ui/Card.jsx';
import { useEffect, useState } from 'react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export default function AdminDashboard() {
  const { token } = useAuth();
  const [agg, setAgg] = useState({ totalStudents: 120, totalSolved: 15230, activeThisWeek: 78, weeklyAgg: [] });

  useEffect(() => {
    async function load() {
      // For now use mock series
      const series = Array.from({ length: 12 }).map((_, i) => ({ week: `W${i + 1}`, solves: 800 + (i * 37) % 120 }));
      setAgg((s) => ({ ...s, weeklyAgg: series }));
      // If backend endpoint exists, replace with: const { data } = await api(token).get('/admin/metrics')
    }
    load();
  }, [token]);

  return (
    <div className="container-page py-8 space-y-8 animate-fade-in">
      <div>
        <h2 className="heading-hero mb-2">Admin Dashboard</h2>
        <p className="text-sm subtle max-w-2xl">
          Monitor overall engagement: student counts, solves, and weekly activity. Use Students and Reports for deeper analysis.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <Card className="group">
          <CardBody>
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm subtle">Total Students</div>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white text-lg">👥</div>
            </div>
            <div className="text-4xl font-extrabold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">{agg.totalStudents}</div>
          </CardBody>
        </Card>
        <Card className="group">
          <CardBody>
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm subtle">Total Solves</div>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-500 to-purple-500 flex items-center justify-center text-white text-lg">✅</div>
            </div>
            <div className="text-4xl font-extrabold bg-gradient-to-r from-brand-600 to-purple-600 bg-clip-text text-transparent">{agg.totalSolved}</div>
          </CardBody>
        </Card>
        <Card className="group">
          <CardBody>
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm subtle">Active This Week</div>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center text-white text-lg">⚡</div>
            </div>
            <div className="text-4xl font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">{agg.activeThisWeek}</div>
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardBody>
          <h3 className="font-bold text-lg mb-4 text-slate-900 dark:text-slate-100">Weekly Activity</h3>
          <div style={{ width: '100%', height: 360 }}>
            <ResponsiveContainer>
              <AreaChart data={agg.weeklyAgg} margin={{ top: 10, right: 24, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSolves" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="solves" stroke="#4f46e5" fillOpacity={1} fill="url(#colorSolves)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="group hover:scale-105 transition-transform">
          <CardBody className="text-center">
            <Link className="btn btn-primary w-full h-12" to="/admin/students">👥 Manage Students</Link>
          </CardBody>
        </Card>
        <Card className="group hover:scale-105 transition-transform">
          <CardBody className="text-center">
            <Link className="btn btn-primary w-full h-12" to="/leaderboards">🏆 View Leaderboards</Link>
          </CardBody>
        </Card>
        <Card className="group hover:scale-105 transition-transform">
          <CardBody className="text-center">
            <Link className="btn btn-primary w-full h-12" to="/admin/reports">📊 Reports</Link>
          </CardBody>
        </Card>
        <Card className="group hover:scale-105 transition-transform">
          <CardBody className="text-center">
            <Link className="btn btn-primary w-full h-12" to="/admin/import">📥 Import Students</Link>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}


