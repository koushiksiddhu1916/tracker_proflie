import Button from '../../components/ui/Button.jsx';

export default function Reports() {
  function downloadStudents() {
    window.location.href = '/api/admin/reports/students.xlsx';
  }
  return (
    <div className="container-page py-8 animate-fade-in">
      <div className="mb-6">
        <h3 className="heading-hero mb-2">Reports</h3>
        <p className="text-sm subtle max-w-2xl">
          Generate exports for further analysis. Student report includes profile and academic attributes.
        </p>
      </div>
      <Card>
        <CardBody>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-lg mb-2 text-slate-900 dark:text-slate-100">Student Report</h4>
              <p className="text-sm subtle mb-4">Download a comprehensive Excel file with all student information</p>
              <Button onClick={downloadStudents} className="h-12 px-8">
                📥 Download Students Report (XLSX)
              </Button>
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}


