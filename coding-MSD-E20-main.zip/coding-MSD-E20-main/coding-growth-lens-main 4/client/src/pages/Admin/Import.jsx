import { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { api } from '../../services/api.js';
import Button from '../../components/ui/Button.jsx';

export default function Import() {
  const { token } = useAuth();
  const [result, setResult] = useState(null);

  async function onChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append('file', file);
    const { data } = await api(token).post('/admin/students/import', form, { headers: { 'Content-Type': 'multipart/form-data' } });
    setResult(data);
  }

  return (
    <div className="container-page py-8 animate-fade-in">
      <div className="mb-6">
        <h3 className="heading-hero mb-2">Import Students (CSV/XLSX)</h3>
        <p className="text-sm subtle max-w-2xl">
          Upload a CSV/XLSX with columns: name, email, department, college, graduationYear. We will validate and import the records.
        </p>
      </div>
      <Card>
        <CardBody>
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <input className="input flex-1 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100 dark:file:bg-brand-900/30 dark:file:text-brand-300 cursor-pointer" type="file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" onChange={onChange} />
          </div>
          {result && (
            <div className={`mt-4 p-4 rounded-xl ${result.created === result.total ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800' : 'bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800'}`}>
              <p className={`text-sm font-semibold ${result.created === result.total ? 'text-green-700 dark:text-green-300' : 'text-amber-700 dark:text-amber-300'}`}>
                Imported {result.created} of {result.total} students
              </p>
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}


