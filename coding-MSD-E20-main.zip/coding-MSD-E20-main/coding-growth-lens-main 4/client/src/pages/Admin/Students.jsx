import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { api } from '../../services/api.js';
import Button from '../../components/ui/Button.jsx';
import { Field, Input } from '../../components/ui/Input.jsx';

export default function Students() {
  const { token } = useAuth();
  const [students, setStudents] = useState([]);
  const [filters, setFilters] = useState({ department: '', college: '', graduationYear: '', q: '' });

  async function load() {
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v));
    const { data } = await api(token).get('/admin/students', { params });
    setStudents(data.students);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="container-page py-8 animate-fade-in">
      <div className="mb-6">
        <h3 className="heading-hero mb-2">Students</h3>
        <p className="text-sm subtle max-w-2xl">
          Filter by department, college, or year and search by name/email. Use Reports to export detailed analytics.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-4">
        <Input placeholder="Department" value={filters.department} onChange={(e) => setFilters({ ...filters, department: e.target.value })} />
        <Input placeholder="College" value={filters.college} onChange={(e) => setFilters({ ...filters, college: e.target.value })} />
        <Input placeholder="Grad Year" value={filters.graduationYear} onChange={(e) => setFilters({ ...filters, graduationYear: e.target.value })} />
        <Input placeholder="Search name/email" value={filters.q} onChange={(e) => setFilters({ ...filters, q: e.target.value })} />
        <Button onClick={load}>Apply</Button>
      </div>
      <div className="table-container">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 dark:bg-slate-900/60">
            <tr className="text-left">
              <th className="p-3">Name</th>
              <th className="p-3">Email</th>
              <th className="p-3">Department</th>
              <th className="p-3">College</th>
              <th className="p-3">Grad Year</th>
            </tr>
          </thead>
          <tbody>
            {students.map((s) => (
              <tr key={s._id} className="border-t border-slate-100 dark:border-slate-800">
                <td className="p-3">{s.name}</td>
                <td className="p-3">{s.email}</td>
                <td className="p-3">{s.department}</td>
                <td className="p-3">{s.college}</td>
                <td className="p-3">{s.graduationYear}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}


