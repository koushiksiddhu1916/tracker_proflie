export default function InfoBar({ children }) {
  return (
    <div className="mb-4 rounded-lg border border-sky-200 bg-sky-50 text-sky-800 dark:border-sky-900/40 dark:bg-sky-900/20 dark:text-sky-200 p-3 text-sm">
      {children}
    </div>
  );
}


