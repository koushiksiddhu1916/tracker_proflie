export function Field({ label, children }) {
  return (
    <div className="mb-4">
      {label && <label className="label">{label}</label>}
      {children}
    </div>
  );
}

export function Input(props) {
  return <input className="input" {...props} />;
}

export function Select(props) {
  return <select className="input" {...props} />;
}


