export function Card({ className = '', children }) {
  return <div className={`card ${className}`}>{children}</div>;
}

export function CardBody({ className = '', children }) {
  return <div className={`card-body ${className}`}>{children}</div>;
}


