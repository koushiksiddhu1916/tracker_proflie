import { api } from './api.js';

export async function loginApi(email, password) {
  const { data } = await api().post('/auth/login', { email, password });
  return data;
}

export async function registerApi(payload) {
  const { data } = await api().post('/auth/register', payload);
  return data;
}

export async function getMe(token) {
  const { data } = await api(token).get('/student/me');
  return data;
}


