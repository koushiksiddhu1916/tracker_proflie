import axios from 'axios';

export function api(token) {
  // Use relative API path for Netlify deployment
  // Netlify will proxy /api/* requests to Netlify Functions
  // Only use VITE_API_URL if it's explicitly set AND not pointing to localhost (for production)
  const envApiUrl = import.meta.env.VITE_API_URL;
  const baseURL = (envApiUrl && !envApiUrl.includes('localhost')) 
    ? envApiUrl 
    : '/api';
  
  const instance = axios.create({ 
    baseURL,
    headers: {
      'Content-Type': 'application/json'
    },
    withCredentials: false
  });
  if (token) {
    instance.interceptors.request.use((config) => ({
      ...config,
      headers: {
        ...config.headers,
        Authorization: `Bearer ${token}`
      }
    }));
  }
  return instance;
}