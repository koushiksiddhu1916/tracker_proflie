import serverless from 'serverless-http';
import app from '../../server/src/app.js';
import { connectToDatabase } from '../../server/src/config/db.js';

// Connect to database on function initialization
let dbConnected = false;
let serverlessHandler = null;

const handler = async (event, context) => {
  // Ensure database connection
  if (!dbConnected) {
    try {
      await connectToDatabase();
      dbConnected = true;
      console.log('Database connected successfully');
    } catch (error) {
      console.error('Database connection error:', error);
      return {
        statusCode: 500,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
        },
        body: JSON.stringify({ error: 'Database connection failed', message: error.message })
      };
    }
  }

  // Initialize serverless handler lazily
  if (!serverlessHandler) {
    serverlessHandler = serverless(app, {
      binary: ['image/*', 'application/pdf'],
      request: (request, event, context) => {
        // Ensure context is available for timeouts
        request.context = context;
      }
    });
  }

  // Handle CORS preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Accept',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
        'Access-Control-Max-Age': '86400'
      },
      body: ''
    };
  }

  try {
    // Netlify redirects /api/* to /.netlify/functions/api/:splat
    // When using :splat, the captured path (after /api/) is in pathParameters.splat
    // Example: /api/auth/register -> pathParameters.splat = "auth/register"
    
    let requestPath = '/';
    
    // Check if we have pathParameters with splat (from :splat redirect)
    if (event.pathParameters && event.pathParameters.splat) {
      // Reconstruct the full path with /api prefix
      requestPath = `/api/${event.pathParameters.splat}`;
    } 
    // Fallback: check event.path
    else {
      requestPath = event.path || event.rawPath || '/';
      
      // If path doesn't start with /api, we need to add it
      if (!requestPath.startsWith('/api')) {
        // If path starts with /.netlify/functions/api, extract the actual route
        if (requestPath.startsWith('/.netlify/functions/api')) {
          // Remove the function path prefix to get the original /api/* path
          requestPath = requestPath.replace('/.netlify/functions/api', '/api');
        } 
        // If it's a valid route path (like /auth/register), prepend /api
        else if (!requestPath.startsWith('/.netlify') && requestPath !== '/') {
          requestPath = `/api${requestPath.startsWith('/') ? '' : '/'}${requestPath}`;
        }
      }
    }
    
    // Update event.path and rawPath for serverless-http
    event.path = requestPath;
    if (event.rawPath) {
      event.rawPath = requestPath;
    }

    // Convert Netlify event to Express-compatible request
    const result = await serverlessHandler(event, context);
    
    // Ensure CORS headers are present in response
    if (result && result.headers) {
      result.headers['Access-Control-Allow-Origin'] = '*';
      result.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With, Accept';
      result.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS, PATCH';
    } else if (result) {
      result.headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Accept',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
        ...result.headers
      };
    }
    
    return result;
  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'Internal server error', message: error.message })
    };
  }
};

export { handler };

