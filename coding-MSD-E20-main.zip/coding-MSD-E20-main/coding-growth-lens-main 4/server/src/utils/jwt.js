import jwt from 'jsonwebtoken';

export function signJwt(payload, options = {}) {
  const secret = process.env.JWT_SECRET || 'dev_secret';
  return jwt.sign(payload, secret, { expiresIn: process.env.JWT_EXPIRES_IN || '7d', ...options });
}

export function verifyJwt(token) {
  const secret = process.env.JWT_SECRET || 'dev_secret';
  return jwt.verify(token, secret);
}


