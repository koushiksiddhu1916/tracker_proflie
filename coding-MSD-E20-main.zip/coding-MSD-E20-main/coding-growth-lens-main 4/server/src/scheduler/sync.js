import cron from 'node-cron';
import PlatformAccount from '../models/PlatformAccount.js';
import Submission from '../models/Submission.js';
import { fetchPlatformStats } from '../services/platforms/index.js';

/**
 * Creates or updates submissions from platform account stats
 * @param {Object} account - PlatformAccount document
 * @param {Object} stats - Platform statistics
 */
async function syncSubmissionsFromStats(account, stats) {
  try {
    // Delete old submissions for this platform account to avoid duplicates
    await Submission.deleteMany({ 
      userId: account.userId, 
      platform: account.platform 
    });

    // Create submissions based on solved problems
    const submissions = [];
    const now = new Date();

    // Add Easy submissions
    if (stats.easySolved > 0) {
      for (let i = 0; i < stats.easySolved; i++) {
        submissions.push({
          userId: account.userId,
          platform: account.platform,
          title: `${account.platform.charAt(0).toUpperCase() + account.platform.slice(1)} Problem ${i + 1}`,
          difficulty: 'Easy',
          status: 'Accepted',
          submittedAt: new Date(now.getTime() - (stats.easySolved - i) * 24 * 60 * 60 * 1000) // Spread over days
        });
      }
    }

    // Add Medium submissions
    if (stats.mediumSolved > 0) {
      for (let i = 0; i < stats.mediumSolved; i++) {
        submissions.push({
          userId: account.userId,
          platform: account.platform,
          title: `${account.platform.charAt(0).toUpperCase() + account.platform.slice(1)} Problem ${i + 1}`,
          difficulty: 'Medium',
          status: 'Accepted',
          submittedAt: new Date(now.getTime() - (stats.mediumSolved - i) * 24 * 60 * 60 * 1000)
        });
      }
    }

    // Add Hard submissions
    if (stats.hardSolved > 0) {
      for (let i = 0; i < stats.hardSolved; i++) {
        submissions.push({
          userId: account.userId,
          platform: account.platform,
          title: `${account.platform.charAt(0).toUpperCase() + account.platform.slice(1)} Problem ${i + 1}`,
          difficulty: 'Hard',
          status: 'Accepted',
          submittedAt: new Date(now.getTime() - (stats.hardSolved - i) * 24 * 60 * 60 * 1000)
        });
      }
    }

    // If totalSolved exists but no difficulty breakdown, create generic submissions
    if (submissions.length === 0 && stats.totalSolved > 0) {
      for (let i = 0; i < stats.totalSolved; i++) {
        submissions.push({
          userId: account.userId,
          platform: account.platform,
          title: `${account.platform.charAt(0).toUpperCase() + account.platform.slice(1)} Problem ${i + 1}`,
          difficulty: 'Easy', // Default to Easy if no breakdown
          status: 'Accepted',
          submittedAt: new Date(now.getTime() - (stats.totalSolved - i) * 24 * 60 * 60 * 1000)
        });
      }
    }

    // Bulk insert submissions
    if (submissions.length > 0) {
      await Submission.insertMany(submissions);
      console.log(`✅ Created ${submissions.length} submissions for ${account.platform}/${account.handle}`);
    }
  } catch (error) {
    console.error(`Error syncing submissions for ${account.platform}/${account.handle}:`, error.message);
  }
}

/**
 * Syncs a single platform account
 * @param {Object} account - PlatformAccount document
 */
async function syncAccount(account, throwErrors = false) {
  try {
    console.log(`Syncing ${account.platform}/${account.handle}...`);
    
    // Clean handle before fetching
    const cleanHandle = account.handle.trim();
    if (!cleanHandle) {
      throw new Error('Handle is empty');
    }

    const stats = await fetchPlatformStats(account.platform, cleanHandle);

    // Update account metadata with latest stats
    account.metadata = {
      ...account.metadata,
      ...stats,
      lastSyncAt: new Date()
    };
    // Remove error state on successful sync
    delete account.metadata.lastError;
    delete account.metadata.lastErrorAt;
    
    account.lastSyncAt = new Date();
    await account.save();

    // Sync submissions from stats
    await syncSubmissionsFromStats(account, stats);

    // Log successful sync with details
    const details = [];
    if (stats.totalSolved) details.push(`${stats.totalSolved} solved`);
    if (stats.rating) details.push(`Rating: ${stats.rating}`);
    if (stats.globalRank) details.push(`Rank: #${stats.globalRank}`);
    
    console.log(`✅ Successfully synced ${account.platform}/${account.handle}${details.length > 0 ? ` - ${details.join(', ')}` : ''}`);
  } catch (error) {
    console.error(`❌ Error syncing ${account.platform}/${account.handle}:`, error.message);
    
    // Update lastSyncAt even on error to avoid retrying too frequently
    account.lastSyncAt = new Date();
    account.metadata = {
      ...account.metadata,
      lastError: error.message,
      lastErrorAt: new Date()
    };
    await account.save().catch(err => {
      console.error(`Failed to save error state for ${account.platform}/${account.handle}:`, err.message);
    });
    
    // Re-throw error if requested (for manual syncs)
    if (throwErrors) {
      throw error;
    }
  }
}

/**
 * Starts the sync scheduler
 */
export function startSyncScheduler() {
  console.log('Starting sync scheduler...');
  
  // Run sync every 30 minutes
  cron.schedule('*/30 * * * *', async () => {
    try {
      console.log('Starting scheduled sync...');
      const accounts = await PlatformAccount.find({});
      
      if (accounts.length === 0) {
        console.log('No platform accounts to sync');
        return;
      }

      console.log(`Found ${accounts.length} accounts to sync`);

      // Sync accounts sequentially to avoid overwhelming APIs
      for (const account of accounts) {
        await syncAccount(account);
        // Small delay between accounts to be respectful to APIs
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      console.log('Scheduled sync completed');
    } catch (error) {
      console.error('Error in scheduled sync:', error.message);
    }
  });

  // Also run sync immediately on startup (optional)
  // Uncomment if you want to sync on server start
  // setTimeout(async () => {
  //   const accounts = await PlatformAccount.find({});
  //   for (const account of accounts) {
  //     await syncAccount(account);
  //   }
  // }, 5000);

  console.log('Sync scheduler started (runs every 30 minutes)');
}

/**
 * Manually trigger sync for a specific account
 * @param {string} accountId - PlatformAccount ID
 */
export async function syncAccountById(accountId) {
  const account = await PlatformAccount.findById(accountId);
  if (!account) {
    throw new Error('Account not found');
  }
  
  // Pass throwErrors=true so errors are propagated
  await syncAccount(account, true);
  
  // Reload account to get updated metadata
  return await PlatformAccount.findById(accountId);
}

/**
 * Manually trigger sync for all accounts
 */
export async function syncAllAccounts() {
  const accounts = await PlatformAccount.find({});
  const results = [];
  
  for (const account of accounts) {
    try {
      await syncAccount(account);
      results.push({ accountId: account._id, success: true });
    } catch (error) {
      results.push({ accountId: account._id, success: false, error: error.message });
    }
  }
  
  return results;
}
