import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { getMe, getMyAccounts, upsertMyAccount, getMyStats, getMySubmissions, syncMyAccount, updateMyAccount, deleteMyAccount, getMyLeaderboards, compileCode } from '../controllers/student.controller.js';

const router = Router();

router.use(requireAuth);
router.get('/me', getMe);
router.get('/accounts', getMyAccounts);
router.get('/leaderboards', getMyLeaderboards);
router.post('/accounts', upsertMyAccount);
router.put('/accounts/:accountId', updateMyAccount);
router.delete('/accounts/:accountId', deleteMyAccount);
router.post('/accounts/:accountId/sync', syncMyAccount);
router.get('/stats', getMyStats);
router.get('/submissions', getMySubmissions);
router.post('/compile', compileCode);

export default router;


