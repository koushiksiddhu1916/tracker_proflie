import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { listStudents, leaderboards, exportReport, importStudents, uploadMiddleware, syncAllPlatformAccounts, syncPlatformAccount } from '../controllers/admin.controller.js';

const router = Router();

router.use(requireAuth, requireRole('admin'));
router.get('/students', listStudents);
router.get('/leaderboards', leaderboards);
router.get('/reports/students.xlsx', exportReport);
router.post('/students/import', uploadMiddleware, importStudents);
router.post('/sync/all', syncAllPlatformAccounts);
router.post('/sync/account/:accountId', syncPlatformAccount);

export default router;


