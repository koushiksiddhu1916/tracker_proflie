import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { fetchPlatformStatsController, getSupportedPlatformsController } from '../controllers/metrics.controller.js';

const router = Router();

router.get('/fetch', requireAuth, fetchPlatformStatsController);
router.get('/platforms', requireAuth, getSupportedPlatformsController);

export default router;


