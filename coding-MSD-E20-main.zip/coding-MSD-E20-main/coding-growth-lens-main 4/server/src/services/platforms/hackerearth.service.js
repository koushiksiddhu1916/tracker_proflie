/**
 * HackerEarth Service - Fetches user statistics from HackerEarth
 */

const HACKEREARTH_API_URL = 'https://www.hackerearth.com/@';

/**
 * Fetches HackerEarth user statistics
 * @param {string} handle - HackerEarth username
 * @returns {Promise<Object>} User statistics
 */
export async function fetchHackerEarthStats(handle) {
  try {
    const url = `${HACKEREARTH_API_URL}${handle}`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    if (!response.ok) {
      if (response.status === 404) {
        throw new Error(`User "${handle}" not found on HackerEarth`);
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();

    // Check if user exists - multiple patterns
    const invalidPatterns = [
      /404/i,
      /not found/i,
      /user does not exist/i,
      /page not found/i,
      /profile not found/i,
      /<title>.*404.*<\/title>/i,
      /<h1>.*404.*<\/h1>/i
    ];
    
    const isInvalidUser = invalidPatterns.some(pattern => pattern.test(html));
    
    if (isInvalidUser) {
      throw new Error(`User "${handle}" not found on HackerEarth`);
    }

    // Extract rating (if available)
    const ratingMatch = html.match(/Rating[:\s]*(\d+)/i);
    const rating = ratingMatch ? parseInt(ratingMatch[1]) : null;

    // Extract problems solved
    const problemsMatch = html.match(/(\d+)\s*problems?\s*solved/i);
    const totalSolved = problemsMatch ? parseInt(problemsMatch[1]) : 0;

    // Extract badges
    const badgesMatch = html.match(/badges?[:\s]*(\d+)/i);
    const badgesCount = badgesMatch ? parseInt(badgesMatch[1]) : 0;

    return {
      handle,
      platform: 'hackerearth',
      rating,
      totalSolved,
      badgesCount,
      lastUpdated: new Date()
    };
  } catch (error) {
    console.error(`Error fetching HackerEarth stats for ${handle}:`, error.message);
    
    // Preserve "not found" errors
    if (error.message.includes('not found') || error.message.includes('404')) {
      throw error;
    }
    
    throw new Error(`Failed to fetch HackerEarth data: ${error.message}`);
  }
}

