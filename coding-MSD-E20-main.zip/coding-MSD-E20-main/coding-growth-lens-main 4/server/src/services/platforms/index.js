/**
 * Unified Platform Service - Routes to appropriate platform service
 * with retry logic and error handling
 */

import { fetchLeetCodeStats } from './leetcode.service.js';
import { fetchHackerRankStats } from './hackerrank.service.js';
import { fetchCodeChefStats } from './codechef.service.js';
import { fetchHackerEarthStats } from './hackerearth.service.js';
import { fetchCodeForcesStats } from './codeforces.service.js';
import { fetchAtCoderStats } from './atcoder.service.js';
import { fetchGeeksForGeeksStats } from './geeksforgeeks.service.js';

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // 1 second

/**
 * Sleep utility for retry delays
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Fetches platform statistics with retry logic
 * @param {string} platform - Platform name
 * @param {string} handle - Username/handle
 * @returns {Promise<Object>} Platform statistics
 */
export async function fetchPlatformStats(platform, handle) {
  if (!handle || handle.trim() === '') {
    throw new Error('Handle/username is required');
  }

  let lastError;
  
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      let stats;
      
      switch (platform.toLowerCase()) {
        case 'leetcode':
          stats = await fetchLeetCodeStats(handle);
          break;
        case 'hackerrank':
          stats = await fetchHackerRankStats(handle);
          break;
        case 'codechef':
          stats = await fetchCodeChefStats(handle);
          break;
        case 'hackerearth':
          stats = await fetchHackerEarthStats(handle);
          break;
        case 'codeforces':
          stats = await fetchCodeForcesStats(handle);
          break;
        case 'atcoder':
          stats = await fetchAtCoderStats(handle);
          break;
        case 'geeksforgeeks':
          stats = await fetchGeeksForGeeksStats(handle);
          break;
        default:
          throw new Error(`Unsupported platform: ${platform}`);
      }

      return stats;
    } catch (error) {
      lastError = error;
      
      // Don't retry on 404/user not found errors
      if (error.message.includes('not found') || error.message.includes('404')) {
        throw error;
      }

      // Log retry attempt
      if (attempt < MAX_RETRIES) {
        console.warn(`Attempt ${attempt} failed for ${platform}/${handle}, retrying...`);
        await sleep(RETRY_DELAY * attempt); // Exponential backoff
      }
    }
  }

  // All retries failed
  throw new Error(`Failed to fetch ${platform} data after ${MAX_RETRIES} attempts: ${lastError?.message || 'Unknown error'}`);
}

/**
 * Get list of supported platforms
 */
export function getSupportedPlatforms() {
  return [
    'leetcode',
    'hackerrank',
    'codechef',
    'hackerearth',
    'codeforces',
    'atcoder',
    'geeksforgeeks'
  ];
}

