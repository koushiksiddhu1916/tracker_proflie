/**
 * GeeksforGeeks Service - Fetches user statistics from GeeksforGeeks
 */

const GFG_API_URL = 'https://auth.geeksforgeeks.org/api/user/';

/**
 * Fetches GeeksforGeeks user statistics
 * @param {string} handle - GeeksforGeeks username
 * @returns {Promise<Object>} User statistics
 */
export async function fetchGeeksForGeeksStats(handle) {
  try {
    // GeeksforGeeks uses a different approach - we'll try to fetch via their API
    const url = `${GFG_API_URL}${handle}`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    if (!response.ok) {
      // Try scraping profile page as fallback
      return await fetchGeeksForGeeksStatsScraping(handle);
    }

    const data = await response.json();

    if (data.error || !data.user) {
      const errorMsg = data.error || 'User not found';
      if (errorMsg.toLowerCase().includes('not found') || 
          errorMsg.toLowerCase().includes('does not exist') ||
          errorMsg.toLowerCase().includes('invalid')) {
        throw new Error(`User "${handle}" not found on GeeksforGeeks`);
      }
      throw new Error(`GeeksforGeeks API error: ${errorMsg}`);
    }

    const user = data.user;

    return {
      handle,
      platform: 'geeksforgeeks',
      totalSolved: user.total_problems_solved || 0,
      streak: user.current_streak || 0,
      longestStreak: user.longest_streak || 0,
      institution: user.institution || null,
      lastUpdated: new Date()
    };
  } catch (error) {
    // Fallback to scraping
    try {
      return await fetchGeeksForGeeksStatsScraping(handle);
    } catch (scrapeError) {
      console.error(`Error fetching GeeksforGeeks stats for ${handle}:`, scrapeError.message);
      
      // Preserve "not found" errors
      if (scrapeError.message.includes('not found') || scrapeError.message.includes('404')) {
        throw scrapeError;
      }
      
      // If original error was "not found", preserve it
      if (error.message.includes('not found') || error.message.includes('404')) {
        throw error;
      }
      
      throw new Error(`Failed to fetch GeeksforGeeks data: ${scrapeError.message}`);
    }
  }
}

/**
 * Fallback method: Scrapes GeeksforGeeks profile page
 */
async function fetchGeeksForGeeksStatsScraping(handle) {
  const url = `https://www.geeksforgeeks.org/user/${handle}/`;
  
  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
  });

  if (!response.ok) {
    if (response.status === 404) {
      throw new Error(`User "${handle}" not found on GeeksforGeeks`);
    }
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  const html = await response.text();

  // Check if user exists
  const invalidPatterns = [
    /404/i,
    /not found/i,
    /user does not exist/i,
    /page not found/i,
    /profile not found/i,
    /<title>.*404.*<\/title>/i,
    /<h1>.*404.*<\/h1>/i
  ];
  
  const isInvalidUser = invalidPatterns.some(pattern => pattern.test(html));
  
  if (isInvalidUser || response.status === 404) {
    throw new Error(`User "${handle}" not found on GeeksforGeeks`);
  }

  // Extract problems solved
  const problemsMatch = html.match(/(\d+)\s*problems?\s*solved/i) ||
                       html.match(/Problems Solved[:\s]*(\d+)/i);
  const totalSolved = problemsMatch ? parseInt(problemsMatch[1]) : 0;

  // Extract coding score
  const scoreMatch = html.match(/Coding Score[:\s]*(\d+)/i);
  const codingScore = scoreMatch ? parseInt(scoreMatch[1]) : null;

  return {
    handle,
    platform: 'geeksforgeeks',
    totalSolved,
    codingScore,
    lastUpdated: new Date()
  };
}

