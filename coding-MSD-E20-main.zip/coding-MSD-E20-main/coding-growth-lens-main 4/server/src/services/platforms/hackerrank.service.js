/**
 * HackerRank Service - Fetches user statistics from HackerRank by scraping profile page
 */

const HACKERRANK_BASE_URL = 'https://www.hackerrank.com/';

/**
 * Fetches HackerRank user statistics by scraping profile page
 * @param {string} handle - HackerRank username
 * @returns {Promise<Object>} User statistics
 */
export async function fetchHackerRankStats(handle) {
  try {
    // Extract username from URL if provided
    let cleanHandle = handle.trim();
    
    // Remove URL parts if present
    if (cleanHandle.includes('hackerrank.com')) {
      const match = cleanHandle.match(/hackerrank\.com\/([^\/\?]+)/);
      if (match) {
        cleanHandle = match[1];
      }
    }
    
    // Remove leading/trailing slashes and spaces
    cleanHandle = cleanHandle.replace(/^\/+|\/+$/g, '').trim();
    
    if (!cleanHandle) {
      throw new Error('HackerRank username is required');
    }

    const url = `${HACKERRANK_BASE_URL}${cleanHandle}`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
      }
    });

    if (!response.ok) {
      if (response.status === 404) {
        throw new Error(`User "${cleanHandle}" not found on HackerRank`);
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();

    // Check if user profile exists - HackerRank shows specific patterns for invalid users
    const invalidUserPatterns = [
      /404/i,
      /page not found/i,
      /user not found/i,
      /profile not found/i,
      /does not exist/i,
      /couldn't find/i,
      /<title>.*404.*<\/title>/i,
      /<h1>.*404.*<\/h1>/i,
      /the page you're looking for doesn't exist/i,
      /sorry.*page.*not.*found/i
    ];

    // Check if HTML indicates user doesn't exist
    const isInvalidUser = invalidUserPatterns.some(pattern => pattern.test(html));
    
    // Double-check by trying the API endpoint (more reliable)
    try {
      const apiUrl = `https://www.hackerrank.com/rest/hackers/${cleanHandle}/badges`;
      const apiResponse = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      
      // If API returns 404, user definitely doesn't exist
      if (apiResponse.status === 404) {
        throw new Error(`User "${cleanHandle}" not found on HackerRank`);
      }
      
      // If API returns error response
      if (!apiResponse.ok && apiResponse.status !== 200) {
        // Check response body for error messages
        try {
          const apiData = await apiResponse.json();
          if (apiData.error || apiData.message) {
            throw new Error(`User "${cleanHandle}" not found on HackerRank`);
          }
        } catch (jsonError) {
          // If can't parse JSON, but status is not OK and HTML shows invalid patterns, user doesn't exist
          if (isInvalidUser) {
            throw new Error(`User "${cleanHandle}" not found on HackerRank`);
          }
        }
      }
    } catch (apiError) {
      // If error message already contains "not found", re-throw it
      if (apiError.message.includes('not found')) {
        throw apiError;
      }
      // If API check fails but we have clear invalid HTML patterns, assume user doesn't exist
      if (isInvalidUser) {
        throw new Error(`User "${cleanHandle}" not found on HackerRank`);
      }
      // Otherwise, continue with HTML parsing (might be a temporary API issue)
    }
    
    // If HTML clearly shows invalid user, throw error
    if (isInvalidUser) {
      throw new Error(`User "${cleanHandle}" not found on HackerRank`);
    }

    // Extract statistics from HTML
    let totalSolved = 0;
    let badges = [];
    let contestCount = 0;
    
    // Try to extract total problems solved
    const solvedPatterns = [
      /(\d+)\s+problems?\s+solved/i,
      /problems?\s+solved[:\s]*(\d+)/i,
      /"solved":\s*(\d+)/,
      /data-solved="(\d+)"/,
      /<span[^>]*class="[^"]*solved[^"]*"[^>]*>(\d+)<\/span>/i
    ];
    
    for (const pattern of solvedPatterns) {
      const match = html.match(pattern);
      if (match) {
        totalSolved = parseInt(match[1]) || 0;
        break;
      }
    }

    // Try to extract badges count
    const badgePatterns = [
      /(\d+)\s+badges?/i,
      /badges?[:\s]*(\d+)/i,
      /"badges":\s*(\d+)/,
      /data-badges="(\d+)"/
    ];
    
    for (const pattern of badgePatterns) {
      const match = html.match(pattern);
      if (match) {
        badges = [{ count: parseInt(match[1]) || 0 }];
        break;
      }
    }

    // Try to extract contest participation
    const contestPatterns = [
      /(\d+)\s+contests?/i,
      /contests?[:\s]*(\d+)/i,
      /"contests":\s*(\d+)/,
      /data-contests="(\d+)"/
    ];
    
    for (const pattern of contestPatterns) {
      const match = html.match(pattern);
      if (match) {
        contestCount = parseInt(match[1]) || 0;
        break;
      }
    }

    // Try alternative API endpoint as fallback
    if (totalSolved === 0) {
      try {
        const apiUrl = `https://www.hackerrank.com/rest/hackers/${cleanHandle}/badges`;
        const apiResponse = await fetch(apiUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          }
        });
        
        if (apiResponse.ok) {
          const apiData = await apiResponse.json();
          if (apiData.data && Array.isArray(apiData.data)) {
            badges = apiData.data.map(b => ({ name: b.name || b.badge_name, badge_type: b.badge_type || 'standard' }));
          }
        }
      } catch (apiError) {
        console.warn(`HackerRank API fallback failed: ${apiError.message}`);
      }
    }

    return {
      handle: cleanHandle,
      platform: 'hackerrank',
      totalSolved,
      badges: badges.length > 0 ? badges : null,
      contestCount,
      lastUpdated: new Date()
    };
  } catch (error) {
    console.error(`Error fetching HackerRank stats for ${handle}:`, error.message);
    
    // Provide more helpful error messages
    if (error.message.includes('not found') || error.message.includes('404')) {
      throw new Error(`User "${handle}" not found on HackerRank. Please check your username.`);
    }
    
    throw new Error(`Failed to fetch HackerRank data: ${error.message}`);
  }
}
