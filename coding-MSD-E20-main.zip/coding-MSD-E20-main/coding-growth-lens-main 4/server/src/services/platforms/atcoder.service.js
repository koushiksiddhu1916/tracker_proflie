/**
 * AtCoder Service - Fetches user statistics from AtCoder
 */

const ATCODER_API_URL = 'https://atcoder.jp/users/';

/**
 * Fetches AtCoder user statistics
 * @param {string} handle - AtCoder username
 * @returns {Promise<Object>} User statistics
 */
export async function fetchAtCoderStats(handle) {
  try {
    const url = `${ATCODER_API_URL}${handle}`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    if (!response.ok) {
      if (response.status === 404) {
        throw new Error(`User "${handle}" not found on AtCoder`);
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();

    // Check if user exists - multiple patterns
    const invalidPatterns = [
      /404/i,
      /not found/i,
      /user does not exist/i,
      /page not found/i,
      /profile not found/i,
      /<title>.*404.*<\/title>/i,
      /<h1>.*404.*<\/h1>/i
    ];
    
    const isInvalidUser = invalidPatterns.some(pattern => pattern.test(html));
    
    if (isInvalidUser || response.status === 404) {
      throw new Error(`User "${handle}" not found on AtCoder`);
    }

    // Extract rating
    const ratingMatch = html.match(/<th>Rating<\/th>\s*<td[^>]*>(\d+)<\/td>/i) || 
                        html.match(/Rating[:\s]*(\d+)/i);
    const rating = ratingMatch ? parseInt(ratingMatch[1]) : null;

    // Extract rank
    const rankMatch = html.match(/<th>Rank<\/th>\s*<td[^>]*>(\d+)<\/td>/i) ||
                     html.match(/Rank[:\s]*(\d+)/i);
    const rank = rankMatch ? parseInt(rankMatch[1]) : null;

    // Extract problems solved (if available)
    const problemsMatch = html.match(/(\d+)\s*problems?\s*(?:solved|AC)/i);
    const totalSolved = problemsMatch ? parseInt(problemsMatch[1]) : 0;

    return {
      handle,
      platform: 'atcoder',
      rating,
      rank,
      totalSolved,
      lastUpdated: new Date()
    };
  } catch (error) {
    console.error(`Error fetching AtCoder stats for ${handle}:`, error.message);
    
    // Preserve "not found" errors
    if (error.message.includes('not found') || error.message.includes('404')) {
      throw error;
    }
    
    throw new Error(`Failed to fetch AtCoder data: ${error.message}`);
  }
}

