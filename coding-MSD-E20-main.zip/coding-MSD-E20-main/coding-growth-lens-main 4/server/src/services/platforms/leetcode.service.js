/**
 * LeetCode Service - Fetches user statistics from LeetCode using GraphQL API
 */

const LEETCODE_API_URL = 'https://leetcode.com/graphql';

/**
 * Fetches LeetCode user statistics
 * @param {string} username - LeetCode username
 * @returns {Promise<Object>} User statistics
 */
export async function fetchLeetCodeStats(username) {
  try {
    // Extract username from URL if provided (e.g., "https://leetcode.com/u/thanujkrishna22/" -> "thanujkrishna22")
    let cleanUsername = username.trim();
    
    // Remove URL parts if present
    if (cleanUsername.includes('leetcode.com')) {
      const match = cleanUsername.match(/leetcode\.com\/u\/([^\/]+)/) || cleanUsername.match(/leetcode\.com\/([^\/]+)/);
      if (match) {
        cleanUsername = match[1];
      }
    }
    
    // Remove leading/trailing slashes and spaces
    cleanUsername = cleanUsername.replace(/^\/+|\/+$/g, '').trim();
    
    if (!cleanUsername) {
      throw new Error('LeetCode username is required');
    }

    // Use the correct GraphQL query structure for LeetCode
    const query = {
      query: `
        query userPublicProfile($username: String!) {
          matchedUser(username: $username) {
            username
            submitStats: submitStatsGlobal {
              acSubmissionNum {
                difficulty
                count
                submissions
              }
              totalSubmissionNum {
                difficulty
                count
                submissions
              }
            }
            profile {
              ranking
              reputation
              starRating
            }
            contributions {
              points
            }
            contestBadge {
              name
            }
          }
        }
      `,
      variables: { username: cleanUsername }
    };

    try {
      const response = await fetch(LEETCODE_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json',
          'Accept-Language': 'en-US,en;q=0.9',
          'Origin': 'https://leetcode.com',
          'Referer': `https://leetcode.com/u/${cleanUsername}/`,
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(query)
      });

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error(`User "${cleanUsername}" not found on LeetCode`);
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.errors && data.errors.length > 0) {
        const errorMsg = data.errors[0]?.message || 'LeetCode API error';
        if (errorMsg.includes('matchedUser') || 
            errorMsg.includes('not found') || 
            errorMsg.includes('No user') ||
            errorMsg.toLowerCase().includes('user does not exist')) {
          throw new Error(`User "${cleanUsername}" not found on LeetCode`);
        }
        // If it's not a "not found" error, try fallback scraping
        throw new Error(`LeetCode API error: ${errorMsg}`);
      }

      const matchedUser = data.data?.matchedUser;
      
      // Check if user was matched
      if (!matchedUser || matchedUser === null) {
        throw new Error(`User "${cleanUsername}" not found on LeetCode`);
      }

      if (!matchedUser) {
        // Try fallback scraping if API doesn't return user
        return await fetchLeetCodeStatsScraping(cleanUsername);
      }

      // Extract submission stats
      const submitStats = matchedUser.submitStats;
      const acSubmissionNum = submitStats?.acSubmissionNum || [];
      
      const stats = {
        easy: 0,
        medium: 0,
        hard: 0,
        total: 0
      };

      acSubmissionNum.forEach((item) => {
        const difficulty = item.difficulty?.toLowerCase();
        const count = parseInt(item.count) || 0;
        
        if (difficulty === 'easy') {
          stats.easy = count;
        } else if (difficulty === 'medium') {
          stats.medium = count;
        } else if (difficulty === 'hard') {
          stats.hard = count;
        } else if (difficulty === 'all') {
          stats.total = count;
        }
      });

      // Calculate total if not explicitly provided
      if (stats.total === 0) {
        stats.total = stats.easy + stats.medium + stats.hard;
      }

      const profile = matchedUser.profile || {};
      
      return {
        handle: cleanUsername,
        username: matchedUser.username || cleanUsername,
        platform: 'leetcode',
        totalSolved: stats.total,
        easySolved: stats.easy,
        mediumSolved: stats.medium,
        hardSolved: stats.hard,
        ranking: profile.ranking ? parseInt(profile.ranking) : null,
        reputation: profile.reputation ? parseInt(profile.reputation) : null,
        starRating: profile.starRating ? parseInt(profile.starRating) : null,
        contributions: matchedUser.contributions?.points || null,
        lastUpdated: new Date()
      };
    } catch (apiError) {
      // If GraphQL API fails, try scraping as fallback
      console.warn(`LeetCode GraphQL API failed for ${cleanUsername}, trying scraping fallback...`);
      return await fetchLeetCodeStatsScraping(cleanUsername);
    }
  } catch (error) {
    console.error(`Error fetching LeetCode stats for ${username}:`, error.message);
    
    // Provide more helpful error messages
    if (error.message.includes('not found')) {
      throw new Error(`User "${username}" not found on LeetCode. Please check your username.`);
    }
    
    throw new Error(`Failed to fetch LeetCode data: ${error.message}`);
  }
}

/**
 * Fallback method: Scrapes LeetCode profile page
 */
async function fetchLeetCodeStatsScraping(username) {
  try {
    const url = `https://leetcode.com/u/${username}/`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });

    if (!response.ok) {
      if (response.status === 404) {
        throw new Error(`User "${username}" not found on LeetCode`);
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();

    // Extract statistics from HTML
    let totalSolved = 0;
    let easySolved = 0;
    let mediumSolved = 0;
    let hardSolved = 0;
    let ranking = null;

    // Try to extract solved problems count
    const solvedPatterns = [
      /(\d+)\s+problems?\s+solved/i,
      /problems?\s+solved[:\s]*(\d+)/i,
      /"totalSolved":\s*(\d+)/,
      /data-total-solved="(\d+)"/,
      /<span[^>]*class="[^"]*total-solved[^"]*"[^>]*>(\d+)<\/span>/i
    ];
    
    for (const pattern of solvedPatterns) {
      const match = html.match(pattern);
      if (match) {
        totalSolved = parseInt(match[1]) || 0;
        break;
      }
    }

    // Try to extract difficulty breakdown
    const easyMatch = html.match(/"easy"[^}]*"count":\s*(\d+)/i) || html.match(/Easy[:\s]*(\d+)/i);
    if (easyMatch) easySolved = parseInt(easyMatch[1]) || 0;

    const mediumMatch = html.match(/"medium"[^}]*"count":\s*(\d+)/i) || html.match(/Medium[:\s]*(\d+)/i);
    if (mediumMatch) mediumSolved = parseInt(mediumMatch[1]) || 0;

    const hardMatch = html.match(/"hard"[^}]*"count":\s*(\d+)/i) || html.match(/Hard[:\s]*(\d+)/i);
    if (hardMatch) hardSolved = parseInt(hardMatch[1]) || 0;

    // Try to extract ranking
    const rankingMatch = html.match(/"ranking":\s*(\d+)/) || html.match(/Ranking[:\s]*(\d+)/i);
    if (rankingMatch) ranking = parseInt(rankingMatch[1]);

    // Calculate total if not found but we have difficulty breakdown
    if (totalSolved === 0 && (easySolved > 0 || mediumSolved > 0 || hardSolved > 0)) {
      totalSolved = easySolved + mediumSolved + hardSolved;
    }

    return {
      handle: username,
      username: username,
      platform: 'leetcode',
      totalSolved,
      easySolved,
      mediumSolved,
      hardSolved,
      ranking,
      reputation: null,
      starRating: null,
      contributions: null,
      lastUpdated: new Date()
    };
  } catch (error) {
    console.error(`Error scraping LeetCode stats for ${username}:`, error.message);
    throw error;
  }
}

/**
 * Fetches recent LeetCode submissions (limited, as LeetCode doesn't provide full submission history publicly)
 * @param {string} username - LeetCode username
 * @returns {Promise<Array>} Array of submissions
 */
export async function fetchLeetCodeSubmissions(username) {
  try {
    // Note: LeetCode doesn't provide a public API for full submission history
    // This is a placeholder that could be implemented with scraping if needed
    return [];
  } catch (error) {
    console.error(`Error fetching LeetCode submissions for ${username}:`, error.message);
    return [];
  }
}
