/**
 * CodeForces Service - Fetches user statistics from CodeForces API
 */

const CODEFORCES_API_URL = 'https://codeforces.com/api/user.info';

/**
 * Fetches CodeForces user statistics
 * @param {string} handle - CodeForces username
 * @returns {Promise<Object>} User statistics
 */
export async function fetchCodeForcesStats(handle) {
  try {
    const url = `${CODEFORCES_API_URL}?handles=${handle}`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (data.status !== 'OK') {
      // Check if it's a "not found" error
      const comment = data.comment || '';
      if (comment.toLowerCase().includes('not found') || 
          comment.toLowerCase().includes('no such handle') ||
          comment.toLowerCase().includes('handles: user with handle')) {
        throw new Error(`User "${handle}" not found on CodeForces`);
      }
      throw new Error(`CodeForces API error: ${comment || 'Unknown error'}`);
    }

    if (!data.result || data.result.length === 0) {
      throw new Error(`User "${handle}" not found on CodeForces`);
    }

    const user = data.result[0];

    // Fetch submission statistics
    let totalSolved = 0;
    try {
      const submissionsUrl = `https://codeforces.com/api/user.status?handle=${handle}`;
      const submissionsResponse = await fetch(submissionsUrl);
      if (submissionsResponse.ok) {
        const submissionsData = await submissionsResponse.json();
        if (submissionsData.status === 'OK' && submissionsData.result) {
          const solvedProblems = new Set();
          submissionsData.result.forEach((submission) => {
            if (submission.verdict === 'OK') {
              solvedProblems.add(`${submission.problem.contestId}-${submission.problem.index}`);
            }
          });
          totalSolved = solvedProblems.size;
        }
      }
    } catch (err) {
      console.warn(`Could not fetch submissions for ${handle}:`, err.message);
    }

    return {
      handle,
      platform: 'codeforces',
      rating: user.rating || null,
      maxRating: user.maxRating || null,
      rank: user.rank || null,
      maxRank: user.maxRank || null,
      totalSolved,
      contribution: user.contribution || 0,
      lastUpdated: new Date()
    };
  } catch (error) {
    console.error(`Error fetching CodeForces stats for ${handle}:`, error.message);
    
    // Preserve "not found" errors
    if (error.message.includes('not found') || error.message.includes('404')) {
      throw error;
    }
    
    throw new Error(`Failed to fetch CodeForces data: ${error.message}`);
  }
}

