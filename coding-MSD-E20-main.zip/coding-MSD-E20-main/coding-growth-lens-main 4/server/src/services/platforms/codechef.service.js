/**
 * CodeChef Service - Fetches user statistics from CodeChef
 */

const CODECHEF_API_URL = 'https://www.codechef.com/users/';

/**
 * Fetches CodeChef user statistics by scraping profile page
 * @param {string} handle - CodeChef username
 * @returns {Promise<Object>} User statistics
 */
export async function fetchCodeChefStats(handle) {
  try {
    const url = `${CODECHEF_API_URL}${handle}`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();

    // Extract rating from multiple possible patterns
    let rating = null;
    const ratingPatterns = [
      /<div class="rating-number">(\d+)<\/div>/,
      /rating-number[^>]*>(\d+)</,
      /Rating[:\s]*(\d+)/i
    ];
    for (const pattern of ratingPatterns) {
      const match = html.match(pattern);
      if (match) {
        rating = parseInt(match[1]);
        break;
      }
    }

    // Extract stars (can be like "1★" or "★1")
    let stars = null;
    const starsPatterns = [
      /(\d+)\s*★/,
      /★\s*(\d+)/,
      /<div class="rating-star">(.+?)<\/div>/
    ];
    for (const pattern of starsPatterns) {
      const match = html.match(pattern);
      if (match) {
        stars = match[1] || match[0];
        break;
      }
    }

    // Extract global rank - multiple patterns
    let globalRank = null;
    const globalRankPatterns = [
      /Global Rank:\s*<b>(\d+)<\/b>/i,
      /Global Rank[:\s]*(\d+)/i,
      /"global_rank":\s*(\d+)/,
      /(\d+)\s*Global Rank/i
    ];
    for (const pattern of globalRankPatterns) {
      const match = html.match(pattern);
      if (match) {
        globalRank = parseInt(match[1]);
        break;
      }
    }

    // Extract country rank
    let countryRank = null;
    const countryRankPatterns = [
      /Country Rank:\s*<b>(\d+)<\/b>/i,
      /Country Rank[:\s]*(\d+)/i,
      /"country_rank":\s*(\d+)/,
      /(\d+)\s*Country Rank/i
    ];
    for (const pattern of countryRankPatterns) {
      const match = html.match(pattern);
      if (match) {
        countryRank = parseInt(match[1]);
        break;
      }
    }

    // Extract total problems solved - multiple patterns
    let totalSolved = 0;
    const problemsPatterns = [
      /Total Problems Solved:\s*(\d+)/i,
      /Problems Solved:\s*<b>(\d+)<\/b>/i,
      /(\d+)\s*Problems Solved/i,
      /"total_problems_solved":\s*(\d+)/,
      /problems solved[:\s]*(\d+)/i
    ];
    for (const pattern of problemsPatterns) {
      const match = html.match(pattern);
      if (match) {
        totalSolved = parseInt(match[1]);
        break;
      }
    }

    // Extract highest rating if available
    let highestRating = null;
    const highestRatingPatterns = [
      /\(Highest Rating\s*(\d+)\)/i,
      /Highest Rating[:\s]*(\d+)/i,
      /highest.*?(\d+)/i
    ];
    for (const pattern of highestRatingPatterns) {
      const match = html.match(pattern);
      if (match) {
        highestRating = parseInt(match[1]);
        break;
      }
    }

    // Check if user exists - multiple patterns
    const invalidPatterns = [
      /user not found/i,
      /404/i,
      /page not found/i,
      /profile not found/i,
      /does not exist/i,
      /<title>.*404.*<\/title>/i,
      /<h1>.*404.*<\/h1>/i
    ];
    
    const isInvalidUser = invalidPatterns.some(pattern => pattern.test(html));
    
    // Also check if response was 404
    if (isInvalidUser || (response.status === 404)) {
      throw new Error(`User "${handle}" not found on CodeChef`);
    }

    // If no data found at all and response seems invalid, check
    if (!rating && !totalSolved && html.length < 3000) {
      throw new Error(`User "${handle}" not found on CodeChef`);
    }

    return {
      handle,
      platform: 'codechef',
      rating,
      highestRating,
      stars,
      globalRank,
      countryRank,
      totalSolved,
      lastUpdated: new Date()
    };
  } catch (error) {
    console.error(`Error fetching CodeChef stats for ${handle}:`, error.message);
    
    // Preserve "not found" errors
    if (error.message.includes('not found') || error.message.includes('404')) {
      throw error;
    }
    
    throw new Error(`Failed to fetch CodeChef data: ${error.message}`);
  }
}
