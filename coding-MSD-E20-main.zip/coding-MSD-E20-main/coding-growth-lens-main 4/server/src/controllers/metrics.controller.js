import { fetchPlatformStats, getSupportedPlatforms } from '../services/platforms/index.js';

export async function fetchPlatformStatsController(req, res) {
  try {
    const { platform, handle } = req.query;
    
    if (!platform || !handle) {
      return res.status(400).json({ 
        message: 'platform and handle are required',
        supportedPlatforms: getSupportedPlatforms()
      });
    }

    const data = await fetchPlatformStats(platform, handle);
    res.json({ platform, handle, data });
  } catch (error) {
    console.error('Error fetching platform stats:', error);
    res.status(error.message.includes('not found') || error.message.includes('404') ? 404 : 500).json({
      message: error.message,
      supportedPlatforms: getSupportedPlatforms()
    });
  }
}

export async function getSupportedPlatformsController(req, res) {
  res.json({ platforms: getSupportedPlatforms() });
}


