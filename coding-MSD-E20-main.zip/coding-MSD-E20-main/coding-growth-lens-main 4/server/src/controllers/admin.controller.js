import User from '../models/User.js';
import Submission from '../models/Submission.js';
import PlatformAccount from '../models/PlatformAccount.js';
import xlsx from 'xlsx';
import multer from 'multer';
import { syncAllAccounts, syncAccountById } from '../scheduler/sync.js';

export async function listStudents(req, res) {
  const { department, college, graduationYear, q } = req.query;
  const filter = { role: 'student' };
  if (department) filter.department = department;
  if (college) filter.college = college;
  if (graduationYear) filter.graduationYear = Number(graduationYear);
  if (q) filter.$or = [{ name: new RegExp(q, 'i') }, { email: new RegExp(q, 'i') }];
  const students = await User.find(filter).select('-passwordHash').limit(500);
  res.json({ students });
}

export async function leaderboards(req, res) {
  try {
    const { scope } = req.query; // department|college|global
    
    // Get platform account stats (primary source - most accurate)
    const platformStats = await PlatformAccount.aggregate([
      { $match: { metadata: { $exists: true, $ne: null } } },
      {
        $group: {
          _id: '$userId',
          solved: {
            $sum: {
              $ifNull: ['$metadata.totalSolved', 0]
            }
          }
        }
      }
    ]);

    // Get submissions count (fallback for users without platform accounts)
    const submissionStats = await Submission.aggregate([
      { $match: { status: 'Accepted' } },
      { $group: { _id: '$userId', solved: { $sum: 1 } } }
    ]);

    // Combine stats - prefer platform account stats, fallback to submissions
    const combinedStats = new Map();
    
    // Add platform account stats first (primary source)
    platformStats.forEach(stat => {
      combinedStats.set(stat._id.toString(), stat.solved);
    });

    // Add submission stats only if user doesn't have platform account stats
    submissionStats.forEach(stat => {
      const userId = stat._id.toString();
      if (!combinedStats.has(userId)) {
        combinedStats.set(userId, stat.solved);
      }
    });

    // Convert to array and fetch user details
    const mongoose = await import('mongoose');
    const userIds = Array.from(combinedStats.keys()).map(id => new mongoose.default.Types.ObjectId(id));
    const users = await User.find({ _id: { $in: userIds } }).lean();

    // Combine and format results
    const results = users.map(user => ({
      userId: user._id,
      name: user.name,
      solved: combinedStats.get(user._id.toString()) || 0,
      department: user.department || '',
      college: user.college || ''
    })).sort((a, b) => b.solved - a.solved);

    // Filter by scope and add ranks
    let formattedResults = [];
    if (scope === 'department') {
      const grouped = {};
      results.forEach(r => {
        const dept = r.department || 'Unknown';
        if (!grouped[dept]) grouped[dept] = [];
        grouped[dept].push(r);
      });
      formattedResults = Object.entries(grouped).map(([dept, users]) => ({
        _id: dept,
        top: users.map((item, index) => ({
          ...item,
          rank: index + 1,
          streak: 0
        }))
      }));
    } else if (scope === 'college') {
      const grouped = {};
      results.forEach(r => {
        const college = r.college || 'Unknown';
        if (!grouped[college]) grouped[college] = [];
        grouped[college].push(r);
      });
      formattedResults = Object.entries(grouped).map(([college, users]) => ({
        _id: college,
        top: users.map((item, index) => ({
          ...item,
          rank: index + 1,
          streak: 0
        }))
      }));
    } else {
      // Global - add rank
      formattedResults = results.slice(0, 200).map((item, index) => ({
        ...item,
        rank: index + 1,
        streak: 0
      }));
    }

    res.json({ results: formattedResults });
  } catch (error) {
    console.error('Error fetching leaderboards:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function syncAllPlatformAccounts(req, res) {
  try {
    const results = await syncAllAccounts();
    const successCount = results.filter(r => r.success).length;
    const failureCount = results.filter(r => !r.success).length;
    
    res.json({
      message: `Sync completed: ${successCount} successful, ${failureCount} failed`,
      results,
      total: results.length,
      success: successCount,
      failed: failureCount
    });
  } catch (error) {
    console.error('Error syncing all accounts:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function syncPlatformAccount(req, res) {
  try {
    const { accountId } = req.params;
    await syncAccountById(accountId);
    const account = await PlatformAccount.findById(accountId);
    
    if (!account) {
      return res.status(404).json({ message: 'Account not found' });
    }
    
    res.json({ account, message: 'Sync completed' });
  } catch (error) {
    console.error('Error syncing account:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function exportReport(req, res) {
  const rows = await User.find({ role: 'student' }).select('name email department college graduationYear').lean();
  const sheet = xlsx.utils.json_to_sheet(rows);
  const wb = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(wb, sheet, 'Students');
  const buf = xlsx.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="students.xlsx"');
  res.send(buf);
}

const upload = multer({ storage: multer.memoryStorage() });
export const uploadMiddleware = upload.single('file');

export async function importStudents(req, res) {
  if (!req.file) return res.status(400).json({ message: 'Missing file' });
  const wb = xlsx.read(req.file.buffer, { type: 'buffer' });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows = xlsx.utils.sheet_to_json(sheet);
  let created = 0;
  for (const row of rows) {
    const email = String(row.email || row.Email || '').trim();
    const name = String(row.name || row.Name || '').trim();
    if (!email || !name) continue;
    const exists = await User.findOne({ email });
    if (exists) continue;
    await User.create({ email, name, passwordHash: '$2a$10$k3WbU3O0Lw.FAKEFIXEDHASHb8eQq8p58Xx8t0c3oWm', role: 'student', department: row.department || '', college: row.college || '', graduationYear: row.graduationYear ? Number(row.graduationYear) : undefined });
    created += 1;
  }
  res.json({ created, total: rows.length });
}


