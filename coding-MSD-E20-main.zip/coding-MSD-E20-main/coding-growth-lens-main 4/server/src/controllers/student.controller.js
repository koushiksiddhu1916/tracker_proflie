import PlatformAccount from '../models/PlatformAccount.js';
import Submission from '../models/Submission.js';
import User from '../models/User.js';
import { syncAccountById } from '../scheduler/sync.js';

export async function getMe(req, res) {
  res.json({ user: req.user });
}

export async function getMyAccounts(req, res) {
  const accounts = await PlatformAccount.find({ userId: req.user.sub });
  res.json({ accounts });
}

export async function upsertMyAccount(req, res) {
  try {
    const { platform, handle } = req.body;
    
    if (!platform || !handle) {
      return res.status(400).json({ message: 'platform and handle are required' });
    }

    // Clean and validate handle
    const cleanHandle = handle.trim();
    if (!cleanHandle) {
      return res.status(400).json({ message: 'Handle cannot be empty' });
    }

    const account = await PlatformAccount.findOneAndUpdate(
      { userId: req.user.sub, platform },
      { handle: cleanHandle, lastSyncAt: null }, // Reset sync time to trigger immediate sync
      { upsert: true, new: true }
    );

    // Trigger sync in background (don't wait for it)
    syncAccountById(account._id.toString()).catch(err => {
      console.error(`Background sync failed for account ${account._id}:`, err.message);
    });

    res.json({ account });
  } catch (error) {
    console.error('Error upserting account:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function syncMyAccount(req, res) {
  try {
    const { accountId } = req.params;
    const account = await PlatformAccount.findOne({ 
      _id: accountId, 
      userId: req.user.sub 
    });

    if (!account) {
      return res.status(404).json({ message: 'Account not found' });
    }

    await syncAccountById(accountId);
    const updatedAccount = await PlatformAccount.findById(accountId);
    res.json({ account: updatedAccount, message: 'Sync completed' });
  } catch (error) {
    console.error('Error syncing account:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function getMyStats(req, res) {
  try {
    const mongoose = await import('mongoose');
    const userId = new mongoose.default.Types.ObjectId(req.user.sub);
    
    // Get platform account stats (primary source - most accurate)
    const platformAccounts = await PlatformAccount.find({ userId }).lean();
    let totalPlatformSolved = 0;
    let platformBreakdown = { Easy: 0, Medium: 0, Hard: 0 };
    let platformRatings = {};
    let globalRank = null;
    let highestRating = 0;
    let weeklyProgress = [];

    platformAccounts.forEach(account => {
      const metadata = account.metadata || {};
      const platformSolved = metadata.totalSolved || 0;
      totalPlatformSolved += platformSolved;
      
      // Sum difficulty breakdown from platform accounts
      if (metadata.easySolved) {
        platformBreakdown.Easy += metadata.easySolved;
      }
      if (metadata.mediumSolved) {
        platformBreakdown.Medium += metadata.mediumSolved;
      }
      if (metadata.hardSolved) {
        platformBreakdown.Hard += metadata.hardSolved;
      }

      // Collect ratings and ranks
      if (metadata.rating) {
        platformRatings[account.platform] = {
          rating: metadata.rating,
          highestRating: metadata.highestRating || metadata.rating,
          globalRank: metadata.globalRank,
          handle: account.handle,
          lastSyncAt: account.lastSyncAt
        };
        if (metadata.highestRating && metadata.highestRating > highestRating) {
          highestRating = metadata.highestRating;
        }
        if (metadata.globalRank && (!globalRank || metadata.globalRank < globalRank)) {
          globalRank = metadata.globalRank;
        }
      }
    });

    // Get submission stats only for submissions NOT from platform accounts
    // (to avoid double-counting, since platform accounts already include their submissions)
    const totalSolved = await Submission.countDocuments({ 
      userId, 
      status: 'Accepted',
      // Only count submissions that don't have a corresponding platform account
      platform: { $nin: platformAccounts.map(acc => acc.platform) }
    });
    
    const byDifficultyAgg = await Submission.aggregate([
      { 
        $match: { 
          userId, 
          status: 'Accepted',
          platform: { $nin: platformAccounts.map(acc => acc.platform) }
        } 
      },
      { $group: { _id: '$difficulty', count: { $sum: 1 } } }
    ]);
    const byDifficulty = byDifficultyAgg.reduce((acc, x) => ({ ...acc, [x._id]: x.count }), {});

    // Combine: Platform accounts are primary, submissions are fallback/add-on
    const combinedTotalSolved = totalPlatformSolved + totalSolved;
    const combinedByDifficulty = {
      Easy: platformBreakdown.Easy + (byDifficulty.Easy || 0),
      Medium: platformBreakdown.Medium + (byDifficulty.Medium || 0),
      Hard: platformBreakdown.Hard + (byDifficulty.Hard || 0)
    };

    // Calculate weekly streak (simplified - can be enhanced)
    const weeklyStreak = 0; // TODO: Calculate from submissions

    // Generate weekly progress (last 12 weeks)
    const now = new Date();
    const weeklyData = [];
    for (let i = 11; i >= 0; i--) {
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - (i * 7));
      weekStart.setHours(0, 0, 0, 0);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 7);
      
      const weekSolved = await Submission.countDocuments({
        userId,
        status: 'Accepted',
        submittedAt: { $gte: weekStart, $lt: weekEnd }
      });
      
      weeklyData.push({
        week: `W${12 - i}`,
        solved: weekSolved
      });
    }

    res.json({ 
      totalSolved: combinedTotalSolved,
      byDifficulty: combinedByDifficulty,
      weeklyStreak,
      weeklyProgress: weeklyData,
      globalRank: globalRank || 0,
      platformAccounts: platformAccounts.map(acc => ({
        platform: acc.platform,
        handle: acc.handle,
        metadata: acc.metadata,
        lastSyncAt: acc.lastSyncAt
      })),
      platformRatings
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function getMyLeaderboards(req, res) {
  try {
    const { scope } = req.query; // department|college|global
    
    // Get platform account stats (primary source - most accurate)
    const platformStats = await PlatformAccount.aggregate([
      { $match: { metadata: { $exists: true, $ne: null } } },
      {
        $group: {
          _id: '$userId',
          solved: {
            $sum: {
              $ifNull: ['$metadata.totalSolved', 0]
            }
          }
        }
      }
    ]);

    // Get submissions count (fallback for users without platform accounts)
    const submissionStats = await Submission.aggregate([
      { $match: { status: 'Accepted' } },
      { $group: { _id: '$userId', solved: { $sum: 1 } } }
    ]);

    // Combine stats - prefer platform account stats, fallback to submissions
    const combinedStats = new Map();
    
    // Add platform account stats first (primary source)
    platformStats.forEach(stat => {
      combinedStats.set(stat._id.toString(), stat.solved);
    });

    // Add submission stats only if user doesn't have platform account stats
    submissionStats.forEach(stat => {
      const userId = stat._id.toString();
      if (!combinedStats.has(userId)) {
        combinedStats.set(userId, stat.solved);
      }
    });

    // Convert to array and fetch user details
    const mongoose = await import('mongoose');
    const userIds = Array.from(combinedStats.keys()).map(id => new mongoose.default.Types.ObjectId(id));
    const users = await User.find({ _id: { $in: userIds } }).lean();

    // Combine and format results
    const results = users.map(user => ({
      userId: user._id,
      name: user.name,
      solved: combinedStats.get(user._id.toString()) || 0,
      department: user.department || '',
      college: user.college || ''
    })).sort((a, b) => b.solved - a.solved);

    // Filter by scope and add ranks
    let formattedResults = [];
    if (scope === 'department') {
      const grouped = {};
      results.forEach(r => {
        const dept = r.department || 'Unknown';
        if (!grouped[dept]) grouped[dept] = [];
        grouped[dept].push(r);
      });
      formattedResults = Object.entries(grouped).map(([dept, users]) => ({
        _id: dept,
        top: users.map((item, index) => ({
          ...item,
          rank: index + 1,
          streak: 0
        }))
      }));
    } else if (scope === 'college') {
      const grouped = {};
      results.forEach(r => {
        const college = r.college || 'Unknown';
        if (!grouped[college]) grouped[college] = [];
        grouped[college].push(r);
      });
      formattedResults = Object.entries(grouped).map(([college, users]) => ({
        _id: college,
        top: users.map((item, index) => ({
          ...item,
          rank: index + 1,
          streak: 0
        }))
      }));
    } else {
      // Global - add rank
      formattedResults = results.slice(0, 200).map((item, index) => ({
        ...item,
        rank: index + 1,
        streak: 0
      }));
    }

    res.json({ results: formattedResults });
  } catch (error) {
    console.error('Error fetching leaderboards:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function deleteMyAccount(req, res) {
  try {
    const { accountId } = req.params;
    const account = await PlatformAccount.findOne({ 
      _id: accountId, 
      userId: req.user.sub 
    });

    if (!account) {
      return res.status(404).json({ message: 'Account not found' });
    }

    await PlatformAccount.deleteOne({ _id: accountId, userId: req.user.sub });
    res.json({ message: 'Account deleted successfully' });
  } catch (error) {
    console.error('Error deleting account:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function updateMyAccount(req, res) {
  try {
    const { accountId } = req.params;
    const { handle } = req.body;
    
    if (!handle || handle.trim() === '') {
      return res.status(400).json({ message: 'Handle is required' });
    }

    const account = await PlatformAccount.findOne({ 
      _id: accountId, 
      userId: req.user.sub 
    });

    if (!account) {
      return res.status(404).json({ message: 'Account not found' });
    }

    account.handle = handle.trim();
    account.lastSyncAt = null; // Reset sync time to trigger immediate sync
    await account.save();

    // Trigger sync in background
    syncAccountById(account._id.toString()).catch(err => {
      console.error(`Background sync failed for account ${account._id}:`, err.message);
    });

    res.json({ account, message: 'Account updated successfully' });
  } catch (error) {
    console.error('Error updating account:', error);
    res.status(500).json({ message: error.message });
  }
}

export async function getMySubmissions(req, res) {
  const limit = Math.min(Number(req.query.limit) || 50, 200);
  const subs = await Submission.find({ userId: req.user.sub }).sort({ submittedAt: -1 }).limit(limit);
  res.json({ submissions: subs });
}

export async function compileCode(req, res) {
  try {
    const { language, code, stdin = '' } = req.body;

    if (!language || !code) {
      return res.status(400).json({ message: 'Language and code are required' });
    }

    // Map our language codes to Judge0 language IDs
    const languageMap = {
      'c': 50,        // C (GCC 9.2.0)
      'cpp': 54,      // C++ (GCC 9.2.0)
      'java': 62,     // Java (OpenJDK 13.0.1)
      'python': 71    // Python (3.8.1)
    };

    const languageId = languageMap[language.toLowerCase()];
    if (!languageId) {
      return res.status(400).json({ message: 'Unsupported language. Supported: c, cpp, java, python' });
    }

    // Use Judge0 API (free tier)
    const JUDGE0_API = 'https://judge0-ce.p.rapidapi.com';
    const JUDGE0_RAPIDAPI_KEY = process.env.JUDGE0_RAPIDAPI_KEY || '';

    // Try Judge0 RapidAPI first (if key is provided), otherwise use public instance
    let judge0Url = 'https://judge0-ce.p.rapidapi.com/submissions';
    let headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    if (JUDGE0_RAPIDAPI_KEY) {
      headers['X-RapidAPI-Key'] = JUDGE0_RAPIDAPI_KEY;
      headers['X-RapidAPI-Host'] = 'judge0-ce.p.rapidapi.com';
    } else {
      // Use public Judge0 instance (may have rate limits)
      judge0Url = 'https://judge0-ce.p.rapidapi.com/submissions?base64_encoded=false&wait=true';
    }

    // Create submission
    const submissionResponse = await fetch(judge0Url, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        source_code: code,
        language_id: languageId,
        stdin: stdin,
        cpu_time_limit: 10,
        memory_limit: 128000
      })
    });

    if (!submissionResponse.ok) {
      // Fallback: Try alternative free API
      try {
        const alternativeResponse = await fetch('https://api.jdoodle.com/v1/execute', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            script: code,
            language: language.toLowerCase(),
            versionIndex: language === 'java' ? '3' : '0',
            stdin: stdin,
            clientId: process.env.JDOODLE_CLIENT_ID || '',
            clientSecret: process.env.JDOODLE_CLIENT_SECRET || ''
          })
        });

        if (alternativeResponse.ok) {
          const altData = await alternativeResponse.json();
          return res.json({
            stdout: altData.output || '',
            stderr: altData.error || '',
            error: altData.error || null
          });
        }
      } catch (altError) {
        console.error('Alternative API failed:', altError);
      }

      throw new Error(`Judge0 API error: ${submissionResponse.status}`);
    }

    const submissionData = await submissionResponse.json();

    // If using wait=true, we get result directly
    if (submissionData.stdout !== undefined || submissionData.stderr !== undefined) {
      return res.json({
        stdout: submissionData.stdout || '',
        stderr: submissionData.stderr || '',
        error: submissionData.stderr || null,
        time: submissionData.time,
        memory: submissionData.memory
      });
    }

    // Otherwise, poll for result
    const token = submissionData.token;
    if (!token) {
      throw new Error('No token received from Judge0');
    }

    // Poll for result (max 10 attempts, 1 second apart)
    let result = null;
    for (let i = 0; i < 10; i++) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const resultUrl = JUDGE0_RAPIDAPI_KEY 
        ? `https://judge0-ce.p.rapidapi.com/submissions/${token}`
        : `https://judge0-ce.p.rapidapi.com/submissions/${token}?base64_encoded=false`;
      
      const resultResponse = await fetch(resultUrl, {
        headers: JUDGE0_RAPIDAPI_KEY ? {
          'X-RapidAPI-Key': JUDGE0_RAPIDAPI_KEY,
          'X-RapidAPI-Host': 'judge0-ce.p.rapidapi.com'
        } : {}
      });

      if (resultResponse.ok) {
        result = await resultResponse.json();
        if (result.status && result.status.id > 2) { // Status > 2 means finished
          break;
        }
      }
    }

    if (!result) {
      throw new Error('Timeout waiting for execution result');
    }

    // Map status codes
    const statusMessages = {
      3: null, // Accepted
      4: 'Wrong Answer',
      5: 'Time Limit Exceeded',
      6: 'Compilation Error',
      7: 'Runtime Error',
      8: 'Runtime Error',
      9: 'Runtime Error',
      10: 'Runtime Error',
      11: 'Runtime Error'
    };

    const errorMessage = statusMessages[result.status?.id] || null;

    res.json({
      stdout: result.stdout || '',
      stderr: result.stderr || result.compile_output || '',
      error: errorMessage || result.stderr || result.compile_output || null,
      time: result.time,
      memory: result.memory
    });

  } catch (error) {
    console.error('Compilation error:', error);
    res.status(500).json({ 
      message: error.message || 'Failed to compile code',
      error: error.message 
    });
  }
}


