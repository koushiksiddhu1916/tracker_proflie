import app from './app.js';
import { connectToDatabase } from './config/db.js';
import { startSyncScheduler } from './scheduler/sync.js';

// Connect to database when the module is imported
// Only start scheduler if not in serverless environment (Netlify/Vercel)
const isServerless = process.env.AWS_LAMBDA_FUNCTION_NAME || process.env.NETLIFY || process.env.VERCEL;

if (!isServerless) {
  connectToDatabase().then(() => {
    console.log('Connected to database');
    startSyncScheduler();
  }).catch((err) => {
    console.error('Failed to connect to database', err);
  });
}

// Export the app for Vercel/Netlify serverless functions
export default app;

// Keep the existing server code for local development
const PORT = process.env.PORT || 5000;
if (process.env.NODE_ENV !== 'production' && !isServerless) {
  app.listen(PORT, () => {
    console.log(`API server listening on port ${PORT}`);
  });
}