import mongoose from 'mongoose';

const submissionSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true, required: true },
    platform: { type: String, enum: ['leetcode', 'hackerrank', 'codechef', 'hackerearth', 'codeforces', 'atcoder', 'geeksforgeeks'], index: true },
    problemId: { type: String },
    title: { type: String },
    difficulty: { type: String, enum: ['Easy', 'Medium', 'Hard'], index: true },
    status: { type: String, enum: ['Accepted', 'Wrong Answer', 'Time Limit', 'Runtime Error'] },
    submittedAt: { type: Date, index: true }
  },
  { timestamps: true }
);

export default mongoose.model('Submission', submissionSchema);


