import mongoose from 'mongoose';

const platformAccountSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true, required: true },
    platform: { type: String, enum: ['leetcode', 'hackerrank', 'codechef', 'hackerearth', 'codeforces', 'atcoder', 'geeksforgeeks'], required: true, index: true },
    handle: { type: String, required: true },
    lastSyncAt: { type: Date },
    metadata: { type: Object }
  },
  { timestamps: true }
);

platformAccountSchema.index({ userId: 1, platform: 1 }, { unique: true });

export default mongoose.model('PlatformAccount', platformAccountSchema);


