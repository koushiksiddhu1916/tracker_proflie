import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ['student'], default: 'student', index: true },
    department: { type: String, index: true },
    college: { type: String, index: true },
    graduationYear: { type: Number, index: true }
  },
  { timestamps: true }
);

export default mongoose.model('User', userSchema);


