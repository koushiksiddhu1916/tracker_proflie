import app from '../server/src/app.js';

// Export the Express app as a serverless function for Vercel
// This handles all routes including /api/*
export default app;
